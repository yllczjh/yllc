﻿/*----------------------------------------------------------------
// Copyright (C) 2019  版权所有。 
//
// 文件名：HttpRequestStatusCode
// 文件功能描述：
// 
// 创建者：名字 (admin)
// 时间：2021-02-24 14:51:18
//
// 修改人：
// 时间：
// 修改说明：
//
// 版本：V1.0.0
//----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model.Enum
{
    public class BusEnum
    {
        public enum HttpRequestStatusCode
        {
            Success,
            Faild
        }

        public enum OrderStatus
        {
            待支付,
            已支付,
            申请退款,
            已退款,
            应用端已支付
        }

        public enum OrderType
        {
            门诊挂号,
            门诊缴费
        }
    }
}
