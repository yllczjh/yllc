﻿

using DAL;
using IDAL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;


namespace DALFactory
{

    public partial class DBSession : IDBSession
    {
    
        private Ijc_qyDal _jc_qyDal;
        public Ijc_qyDal jc_qyDal
        {
            get
            {
                if (_jc_qyDal == null)
                {
                    _jc_qyDal = DALAbstractFactory.CreateDal<Ijc_qyDal>("jc_qyDal");
                }
                return _jc_qyDal;
            }
            set { _jc_qyDal = value; }
        }
    
        private Ijc_qy_cpDal _jc_qy_cpDal;
        public Ijc_qy_cpDal jc_qy_cpDal
        {
            get
            {
                if (_jc_qy_cpDal == null)
                {
                    _jc_qy_cpDal = DALAbstractFactory.CreateDal<Ijc_qy_cpDal>("jc_qy_cpDal");
                }
                return _jc_qy_cpDal;
            }
            set { _jc_qy_cpDal = value; }
        }
    
        private Ijc_yhDal _jc_yhDal;
        public Ijc_yhDal jc_yhDal
        {
            get
            {
                if (_jc_yhDal == null)
                {
                    _jc_yhDal = DALAbstractFactory.CreateDal<Ijc_yhDal>("jc_yhDal");
                }
                return _jc_yhDal;
            }
            set { _jc_yhDal = value; }
        }
    
        private Ijc_yh_cpDal _jc_yh_cpDal;
        public Ijc_yh_cpDal jc_yh_cpDal
        {
            get
            {
                if (_jc_yh_cpDal == null)
                {
                    _jc_yh_cpDal = DALAbstractFactory.CreateDal<Ijc_yh_cpDal>("jc_yh_cpDal");
                }
                return _jc_yh_cpDal;
            }
            set { _jc_yh_cpDal = value; }
        }
    
        private Ijc_yh_qyDal _jc_yh_qyDal;
        public Ijc_yh_qyDal jc_yh_qyDal
        {
            get
            {
                if (_jc_yh_qyDal == null)
                {
                    _jc_yh_qyDal = DALAbstractFactory.CreateDal<Ijc_yh_qyDal>("jc_yh_qyDal");
                }
                return _jc_yh_qyDal;
            }
            set { _jc_yh_qyDal = value; }
        }
    
        private Iyw_kcDal _yw_kcDal;
        public Iyw_kcDal yw_kcDal
        {
            get
            {
                if (_yw_kcDal == null)
                {
                    _yw_kcDal = DALAbstractFactory.CreateDal<Iyw_kcDal>("yw_kcDal");
                }
                return _yw_kcDal;
            }
            set { _yw_kcDal = value; }
        }
    
        private Iyw_mxDal _yw_mxDal;
        public Iyw_mxDal yw_mxDal
        {
            get
            {
                if (_yw_mxDal == null)
                {
                    _yw_mxDal = DALAbstractFactory.CreateDal<Iyw_mxDal>("yw_mxDal");
                }
                return _yw_mxDal;
            }
            set { _yw_mxDal = value; }
        }
    }
}
