﻿/*----------------------------------------------------------------
// Copyright (C) 2019  版权所有。 
//
// 文件名：DALAbstractFactory
// 文件功能描述：
// 
// 创建者：名字 (admin)
// 时间：2020-09-24 15:21:43
//
// 修改人：
// 时间：
// 修改说明：
//
// 版本：V1.0.0
//----------------------------------------------------------------*/
using IDAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DALFactory
{
    /// <summary>
    /// 抽象工厂：跟工厂一样，都是为了解决对象的创建问题。抽象工厂通过反射创建类的实例
    /// </summary>
    public class DALAbstractFactory
    {
        private static readonly string DalNamespace = System.Configuration.ConfigurationManager.AppSettings["DalNamespace"];
        private static readonly string DalAssembly = System.Configuration.ConfigurationManager.AppSettings["DalAssembly"];

        //public static IMenuDal CreateMenuDal()
        //{
        //    string fullClassName = DalNamespace + ".MenuDal";
        //    return CreateInstance(fullClassName, DalAssembly) as IMenuDal;
        //}

        //private static object CreateInstance(string fullClassName, string assemblyPath)
        //{
        //    Assembly assembly = Assembly.Load(assemblyPath);//加载程序集
        //    return assembly.CreateInstance(fullClassName);
        //}

        private static object CreateIntstance(string fullClassName, string assemblyPath)
        {
            var assembly = Assembly.Load(assemblyPath);
            var obj = assembly.CreateInstance(fullClassName);
            return obj;
        }

        public static T CreateDal<T>(string dalName)
        {
            string fullClassName = DalNamespace + "." + dalName;
            return (T)CreateIntstance(fullClassName, DalAssembly);
        }
    }
}
