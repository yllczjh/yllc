﻿using DAL;
using IDAL;
using Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DALFactory
{
    /// <summary>
    /// DBSession：数据会话层，工厂类用于与业务层解耦
    /// </summary>
    public partial class DBSession : IDBSession
    {
        private string _MbjectId;
        public string ObjectId { get { return _MbjectId; } set { _MbjectId = value; } }

        public DBSession()
        {
            ObjectId = Guid.NewGuid().ToString();
        }
        //DbContext efDb = new solutionEntities();
        DbContext efDb = DBContextFactory.CreateDBContext();
        //private IMenuDal _MenuDal;
        //public IMenuDal MenuDal
        //{
        //    get
        //    {
        //        if (_MenuDal == null)
        //            //_MenuDal = new DAL.MenuDal();
        //            _MenuDal = DALAbstractFactory.CreateMenuDal();
        //        return _MenuDal;
        //    }
        //    set { _MenuDal = value; }
        //}

        public bool SaveChanges()
        {
            try
            {
                return efDb.SaveChanges() > 0;
            }
            catch (System.Data.Entity.Validation.DbEntityValidationException e)
            {
                string msg = "";
                foreach (var error in e.EntityValidationErrors)
                {
                    msg += error.Entry.Entity.ToString();
                    foreach (var dbValidationError in error.ValidationErrors)
                    {
                        msg += dbValidationError.ErrorMessage;
                    }
                }
                throw new Exception(msg);
            }
            catch (System.Data.Entity.Infrastructure.DbUpdateException e)
            {
                throw new Exception(GetExceptionMessage(e));
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        private string GetExceptionMessage(Exception e)
        {
            string msg = e.Message;
            if (e.InnerException != null)
            {
                return msg + GetExceptionMessage(e.InnerException);
            }
            return msg;
        }
    }
}
