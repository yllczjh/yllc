﻿/*----------------------------------------------------------------
// Copyright (C) 2019  版权所有。 
//
// 文件名：AccessToken
// 文件功能描述：
// 
// 创建者：名字 (admin)
// 时间：2020-10-29 15:37:45
//
// 修改人：
// 时间：
// 修改说明：
//
// 版本：V1.0.0
//----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utils
{
    public class AccessToken
    {
        // 获取到的凭证  
        private string token;
        // 凭证有效时间，单位：秒  
        private int expiresIn;
        // 获取到凭证的时间
        private DateTime acquireTime;

        /// <summary>
        /// 是否需要获取新的accessToken，如果返回true则获取新的accessToken
        /// </summary>
        public bool IsGetNewToken
        {
            get
            {
                return acquireTime.AddSeconds((double)(expiresIn - 60)) <= DateTime.Now;
            }
        }



        /// <summary>
        /// 获取货设置凭证有效时间，单位：秒
        /// </summary>
        public int ExpiresIn
        {
            get
            {
                return expiresIn;
            }

            set
            {
                expiresIn = value;
            }
        }

        /// <summary>
        /// 获取或设置凭证
        /// </summary>
        public string Token
        {
            get
            {
                return token;
            }

            set
            {
                acquireTime = DateTime.Now;
                token = value;
            }
        }

        /// <summary>
        /// 获取得到凭证的时间
        /// </summary>
        public DateTime AcquireTime
        {
            get
            {
                return acquireTime;
            }

            //set
            //{
            //    acquireTime = value;
            //}
        }
    }
}

