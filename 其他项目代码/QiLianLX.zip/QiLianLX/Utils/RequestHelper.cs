﻿/*----------------------------------------------------------------
// Copyright (C) 2019  版权所有。 
//
// 文件名：RequestHelper
// 文件功能描述：
// 
// 创建者：名字 (admin)
// 时间：2021-01-05 17:05:12
//
// 修改人：
// 时间：
// 修改说明：
//
// 版本：V1.0.0
//----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utils
{
    public class ResultStruct
    {
        public string Code;
        public DateTime Time;
        public string Info;
        public object Data;
        public ResultStruct()
        {
            Time = DateTime.Now;
        }
    }
    public static class RequestHelper
    {
        public static ResultStruct GetResult(string res)
        {
            object obj = Newtonsoft.Json.JsonConvert.DeserializeObject(res, typeof(ResultStruct));

            var tmp = (ResultStruct)obj;
            tmp.Data = tmp.Data.ToString();

            return tmp;
        }
    }
}
