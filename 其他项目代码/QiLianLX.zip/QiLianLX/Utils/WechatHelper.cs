﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Utils
{
    public class WechatHelper
    {
        /// <summary>
        /// 微信公众平台接口域名
        /// </summary>
        public static string WxApiDomain
        {
            get { return "https://api.weixin.qq.com/"; }
        }

        private static AccessToken _Token;

        /// <summary>
        /// access_token是公众号的全局唯一接口调用凭据，
        /// <value>公众号调用各接口时都需使用access_token。
        /// <para>开发者需要进行妥善保存。access_token的存储至少要保留512个字符空间。</para>access_token的有效期目前为2个小时，需定时刷新，重复获取将导致上次获取的access_token失效。</value>
        /// </summary>
        public static string AccessToken
        {
            get
            {
                if (_Token == null)
                {
                    _Token = getAccessToken(appId, appSecret);
                }
                else
                if (_Token.AcquireTime.AddSeconds(_Token.ExpiresIn <= 0 ? 7200 : _Token.ExpiresIn) < DateTime.Now)
                {
                    _Token = getAccessToken(appId, appSecret);
                }
                return _Token.Token;
            }
        }

        //public static string BaseToken = "weixin";
        //// 第三方用户唯一凭证  
        ////      String appId = "你的appId";  
        //public static string appId = "wx697bdd51d34497ce";
        ////// 第三方用户唯一凭证密钥  
        //public static string appSecret = "af33e0a7b1d1683d033d0cca0da6a8a7";

        /// <summary>
        /// 仅用于微信平台验证开发者服务器
        /// </summary>
        public static string BaseToken = Common.GetAppSetting("BaseToken"); //System.Configuration.ConfigurationManager.AppSettings["BaseToken"];
        public static string appId = System.Configuration.ConfigurationManager.AppSettings["appId"];//"wx4d2cb14f8cf85cab";
        public static string appSecret = System.Configuration.ConfigurationManager.AppSettings["appSecret"];//"aa8fa6841c726eb0e34b9e8ad2a1b7bf";

        /// <summary>
        /// 获取access_token的接口地址（GET） 限200（次/天）
        /// </summary>
        public const String access_token_url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=APPID&secret=APPSECRET";

        public static AccessToken getAccessToken(string appid, string appsecret)
        {
            var accessToken = new AccessToken();
            string requestUrl = access_token_url.Replace("APPID", appid).Replace("APPSECRET", appsecret);
            JObject token = httpsRequest(requestUrl, "GET", null);
            JToken jToken = new JObject();

            if (token.TryGetValue("access_token", out jToken))
            {
                //accessToken = new AccessToken();
                accessToken.ExpiresIn = Convert.ToInt32(token.GetValue("expires_in").ToString());
                accessToken.Token = jToken.ToString();// token.GetValue("access_token").ToString();
                return accessToken;
            }

            throw new Exception("获取基础授权异常:" + token.GetValue("errcode").ToString() + token.GetValue("errmsg").ToString());
        }
      
        /// <summary>
        /// 发起https请求并获取结果
        /// </summary>
        /// <param name="requestUrl">请求地址</param>
        /// <param name="requestMethod">请求方式（GET/POST）</param>
        /// <param name="outputStr">提交的数据 </param>
        /// <returns>通过JObject.getValue(key)获取对象的属性值</returns>
        public static JObject httpsRequest(string requestUrl, string requestMethod, string outputStr)
        {
            System.Net.HttpWebRequest request = null;
            JObject jObj = null;
            try
            {
                request = System.Net.WebRequest.Create(requestUrl) as System.Net.HttpWebRequest;
                request.Method = requestMethod;
                HttpWebResponse response = request.GetResponse() as HttpWebResponse;
                string res = new System.IO.StreamReader(response.GetResponseStream()).ReadToEnd();
                JsonSerializer serializer = new JsonSerializer();
                System.IO.StringReader sr = new System.IO.StringReader(res);

                object obj = serializer.Deserialize(new JsonTextReader(sr), typeof(object));
                jObj = obj as JObject;
            }
            catch (Exception e)
            {
                throw e;
            }
            return jObj;
        }

        /*附录1-JS-SDK使用权限签名算法
        jsapi_ticket
        生成签名之前必须先了解一下jsapi_ticket，jsapi_ticket是公众号用于调用微信JS接口的临时票据。正常情况下，jsapi_ticket的有效期为7200秒，通过access_token来获取。由于获取jsapi_ticket的api调用次数非常有限，频繁刷新jsapi_ticket会导致api调用受限，影响自身业务，开发者必须在自己的服务全局缓存jsapi_ticket 。
        参考以下文档获取access_token（有效期7200秒，开发者必须在自己的服务全局缓存access_token）：https://developers.weixin.qq.com/doc/offiaccount/Basic_Information/Get_access_token.html
        用第一步拿到的access_token 采用http GET方式请求获得jsapi_ticket（有效期7200秒，开发者必须在自己的服务全局缓存jsapi_ticket）：https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=ACCESS_TOKEN&type=jsapi
        成功返回如下JSON：

        {
         "errcode":0,
         "errmsg":"ok",
         "ticket":"bxLdikRXVbTPdHSM05e5u5sUoXNKd8-41ZO3MhKoyN5OfkWITDGgnr2fwJ0m9E8NYzWKVZvdVtaUgWvsdshFKA",
         "expires_in":7200
        }
        获得jsapi_ticket之后，就可以生成JS-SDK权限验证的签名了。*/
        /// <summary>
        ///获取公众号用于调用微信JS接口的临时票据（jsapi_ticket）。
        ///jsapi_ticket的有效期为7200秒，通过access_token来获取。由于获取jsapi_ticket的api调用次数非常有限，频繁刷新jsapi_ticket会导致api调用受限，影响自身业务，开发者必须在自己的服务全局缓存jsapi_ticket 。
        /// </summary>
        /// <param name="accessToken"></param>
        /// <returns></returns>
        public static string GetJsApiTicket(string accessToken)
        {
            //https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=ACCESS_TOKEN&type=jsapi
            string Url = WxApiDomain + "cgi-bin/ticket/getticket?access_token=ACCESS_TOKEN&type=jsapi".Replace("ACCESS_TOKEN", accessToken);
            try
            {
                JObject Ticket = httpsRequest(Url, "GET", null);

                string errcode = Ticket.GetValue("errcode").ToString();
                if (errcode == "0")
                {
                    return Ticket.GetValue("ticket").ToString();
                }
                else
                {
                    throw new Exception($"errcode:{errcode},errmsg:{Ticket.GetValue("errmsg").ToString()}");
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /**
	    * 
	    * 通过code换取网页授权access_token和openid的返回数据，正确时返回的JSON数据包如下：
	    * {
	    *  "access_token":"ACCESS_TOKEN",
	    *  "expires_in":7200,
	    *  "refresh_token":"REFRESH_TOKEN",
	    *  "openid":"OPENID",
	    *  "scope":"SCOPE",
	    *  "unionid": "o6_bmasdasdsad6_2sgVt7hMZOPfL"
	    * }
	    * 其中access_token可用于获取共享收货地址
	    * openid是微信支付jsapi支付接口统一下单时必须的参数
        * 更详细的说明请参考网页授权获取用户基本信息：http://mp.weixin.qq.com/wiki/17/c0f37d5704f0b64713d5d2c37b468d75.html
        * @失败时抛异常WxPayException
	    */
        //public void GetOpenidAndAccessTokenFromCode(string code)
        //{
        //    try
        //    {
        //        //构造获取openid及access_token的url
        //        WxPayData data = new WxPayData();
        //        data.SetValue("appid", WxPayConfig.GetConfig().GetAppID());
        //        data.SetValue("secret", WxPayConfig.GetConfig().GetAppSecret());
        //        data.SetValue("code", code);
        //        data.SetValue("grant_type", "authorization_code");
        //        string url = "https://api.weixin.qq.com/sns/oauth2/access_token?" + data.ToUrl();

        //        //请求url以获取数据
        //        string result = HttpService.Get(url);
        //        //string result = "{\"access_token\":\"41_dYad3KTmXUsxA5f9v_fIndHJHBcymroUsU_8Sd9NbyUriC7CGkLrf9uln2nLLiPehOvT9hOKGPSG5l8evSfz6A\",\"expires_in\":7200,\"refresh_token\":\"41_lSIuo97VAULsum-zlwACZ2x3PjtjEF_PM2oj4z4sjnzEaRx0bQ7jvHroZ60afWpjrd-WL0rNKBZzsjtBKE6dKg\",\"openid\":\"oHQPu0sVahm36H1HsaMlJ-fUb4YE\",\"scope\":\"snsapi_userinfo\"}";
        //        Log.Debug(this.GetType().ToString(), "GetOpenidAndAccessTokenFromCode response : " + result);

        //        //保存access_token，用于收货地址获取
        //        JsonData jd = JsonMapper.ToObject(result);

        //        if (((System.Collections.IDictionary)jd).Contains("errcode"))
        //            throw new Exception($"请求微信用户信息错误,errcode:{jd["errcode"].ToString()}:errmsg:{jd["errmsg"].ToString()}");

        //        access_token = (string)jd["access_token"];

        //        //获取用户openid
        //        openid = (string)jd["openid"];

        //        Log.Debug(this.GetType().ToString(), "Get openid : " + openid);
        //        Log.Debug(this.GetType().ToString(), "Get access_token : " + access_token);
        //    }
        //    catch (Exception ex)
        //    {
        //        Log.Error(this.GetType().ToString(), ex.ToString());
        //        throw new WxPayException(ex.ToString());
        //    }
        //}








    }


}
