﻿

using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace IDAL
{
    public partial interface Ijc_qyDal : IBaseDal<jc_qy>
    {
    }
    public partial interface Ijc_qy_cpDal : IBaseDal<jc_qy_cp>
    {
    }
    public partial interface Ijc_yhDal : IBaseDal<jc_yh>
    {
    }
    public partial interface Ijc_yh_cpDal : IBaseDal<jc_yh_cp>
    {
    }
    public partial interface Ijc_yh_qyDal : IBaseDal<jc_yh_qy>
    {
    }
    public partial interface Iyw_kcDal : IBaseDal<yw_kc>
    {
    }
    public partial interface Iyw_mxDal : IBaseDal<yw_mx>
    {
    }
}