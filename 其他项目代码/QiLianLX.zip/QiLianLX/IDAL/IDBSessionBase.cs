﻿

using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace IDAL
{

    public partial interface IDBSession
    {
    
        Ijc_qyDal jc_qyDal { get; set; }
    
        Ijc_qy_cpDal jc_qy_cpDal { get; set; }
    
        Ijc_yhDal jc_yhDal { get; set; }
    
        Ijc_yh_cpDal jc_yh_cpDal { get; set; }
    
        Ijc_yh_qyDal jc_yh_qyDal { get; set; }
    
        Iyw_kcDal yw_kcDal { get; set; }
    
        Iyw_mxDal yw_mxDal { get; set; }
    }
}
