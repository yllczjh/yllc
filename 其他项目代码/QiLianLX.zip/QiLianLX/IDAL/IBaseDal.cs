﻿/*----------------------------------------------------------------
// Copyright (C) 2019  版权所有。 
//
// 文件名：IBaseDal
// 文件功能描述：
// 
// 创建者：名字 (admin)
// 时间：2020-09-24 11:02:18
//
// 修改人：
// 时间：
// 修改说明：
//
// 版本：V1.0.0
//----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IDAL
{
    public interface IBaseDal<T> where T : class, new()
    {
        T AddEntity(T entity);
        T UpdateEntity(T entity);

        bool DeleteEntity(T entity);
        IQueryable<T> LoadEntitis(System.Linq.Expressions.Expression<Func<T, bool>> whereLambda);
        IQueryable<T> LoadPageEntities<s>(int pageIndex, int pageSize, out int totalCount, System.Linq.Expressions.Expression<Func<T, bool>> whereLamdba, System.Linq.Expressions.Expression<Func<T, s>> orderbyLamdba, bool isAsc);

        //int execPROCEDURE();
    }
}
