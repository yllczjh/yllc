﻿/*----------------------------------------------------------------
// Copyright (C) 2019  版权所有。 
//
// 文件名：ITest
// 文件功能描述：
// 
// 创建者：名字 (admin)
// 时间：2021-04-07 10:23:24
//
// 修改人：
// 时间：
// 修改说明：
//
// 版本：V1.0.0
//----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IDAL
{
    public interface ITest
    {

    }
}
