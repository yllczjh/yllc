﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IDAL
{
    public partial interface IMenuDal : IBaseDal<Menu>
    {
        //Menu AddEntity(Menu entity);
        //Menu UpdateEntity(Menu entity);

        //bool DeleteEntity(Menu entity);
        //IQueryable<Menu> LoadEntitis(System.Linq.Expressions.Expression<Func<Menu>> whereLambda);
        //IQueryable<Menu> LoadPageEntitis(System.Linq.Expressions.Expression<Func<Menu>> whereLambda);
    }
}
