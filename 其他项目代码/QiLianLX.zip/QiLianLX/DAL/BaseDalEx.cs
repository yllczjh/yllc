﻿/*----------------------------------------------------------------
// Copyright (C) 2019  版权所有。 
//
// 文件名：BaseDalEx
// 文件功能描述：
// 
// 创建者：名字 (admin)
// 时间：2021-04-15 11:22:34
//
// 修改人：
// 时间：
// 修改说明：
//
// 版本：V1.0.0
//----------------------------------------------------------------*/
using IDAL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public partial class BaseDal<T> : IBaseDal<T> where T : class, new()
    {
        //        public int execPROCEDURE()
        //        {
        //            SqlParameter[] param = new SqlParameter();
        //        param = new
        //efDb.Database.ExecuteSqlCommand("sp_get_cpml",)
        //        }
    }
}
