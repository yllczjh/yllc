﻿/*----------------------------------------------------------------
// Copyright (C) 2019  版权所有。 
//
// 文件名：DBContextFactory
// 文件功能描述：
// 
// 创建者：名字 (admin)
// 时间：2020-09-25 16:59:11
//
// 修改人：
// 时间：
// 修改说明：
//
// 版本：V1.0.0
//----------------------------------------------------------------*/
using Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace DAL
{
    public class DBContextFactory
    {
        public static DbContext CreateDBContext()
        {
            DbContext db = (DbContext)CallContext.GetData("dbContext");
            if (db == null)
            {
                db = new solutionEntities();
                CallContext.SetData("dbContext", db);
            }
            return db;
        }
    }
}
