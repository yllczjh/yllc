﻿using IDAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using System.Linq.Expressions;
using System.Data.Entity;

namespace DAL
{
    public partial class MenuDal : BaseDal<Menu>, IMenuDal
    {
        //solutionEntities efDb = new solutionEntities();
        DbContext efDb = DBContextFactory.CreateDBContext();

        //public new IQueryable<Menu> LoadEntitis(Expression<Func<Menu, bool>> whereLambda)
        //{
        //    return efDb.Set<Menu>().Where(whereLambda);
        //}
    }
}
