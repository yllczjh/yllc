﻿
using IDAL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
    public partial class jc_qyDal : BaseDal<jc_qy>, Ijc_qyDal
    {
    }
    public partial class jc_qy_cpDal : BaseDal<jc_qy_cp>, Ijc_qy_cpDal
    {
    }
    public partial class jc_yhDal : BaseDal<jc_yh>, Ijc_yhDal
    {
    }
    public partial class jc_yh_cpDal : BaseDal<jc_yh_cp>, Ijc_yh_cpDal
    {
    }
    public partial class jc_yh_qyDal : BaseDal<jc_yh_qy>, Ijc_yh_qyDal
    {
    }
    public partial class yw_kcDal : BaseDal<yw_kc>, Iyw_kcDal
    {
    }
    public partial class yw_mxDal : BaseDal<yw_mx>, Iyw_mxDal
    {
    }
}
