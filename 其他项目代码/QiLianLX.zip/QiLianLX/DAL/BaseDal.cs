﻿/*----------------------------------------------------------------
// Copyright (C) 2019  版权所有。 
//
// 文件名：BaseDal
// 文件功能描述：
// 
// 创建者：名字 (admin)
// 时间：2020-09-24 11:05:32
//
// 修改人：
// 时间：
// 修改说明：
//
// 版本：V1.0.0
//----------------------------------------------------------------*/
using IDAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq.Expressions;
using Model;

namespace DAL
{
    public partial class BaseDal<T> : IBaseDal<T> where T : class, new()
    {
        //protected solutionEntities efDb = new solutionEntities();
        protected System.Data.Entity.DbContext efDb = DBContextFactory.CreateDBContext();
        public T AddEntity(T entity)
        {
            return efDb.Set<T>().Add(entity);
        }

        public bool DeleteEntity(T entity)
        {
            return efDb.Set<T>().Remove(entity) == entity;

        }

        public IQueryable<T> LoadEntitis(Expression<Func<T, bool>> whereLambda)
        {
            return efDb.Set<T>().Where(whereLambda);
        }

        public IQueryable<T> LoadPageEntities<s>(int pageIndex, int pageSize, out int totalCount, System.Linq.Expressions.Expression<Func<T, bool>> whereLambda, System.Linq.Expressions.Expression<Func<T, s>> orderbyLambda, bool isAsc)
        {
            var temp = efDb.Set<T>().Where<T>(whereLambda);
            totalCount = temp.Count();
            if (isAsc)//如果成立表示升序
            {
                temp = temp.OrderBy<T, s>(orderbyLambda).Skip<T>((pageIndex - 1) * pageSize).Take<T>(pageSize);
            }
            else
            {
                temp = temp.OrderByDescending<T, s>(orderbyLambda).Skip<T>((pageIndex - 1) * pageSize).Take<T>(pageSize);
            }
            return temp;
        }

        public T UpdateEntity(T entity)
        {
            efDb.Entry<T>(entity).State = System.Data.Entity.EntityState.Modified;
            return entity;
        }
    }
}
