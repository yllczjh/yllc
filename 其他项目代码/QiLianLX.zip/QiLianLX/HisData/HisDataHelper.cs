﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SupportTools
{
    public static class HisDataHelper
    {
        static string Str平台标识 = "4499";
        static string Str认证密钥 = "123456";
        static string Str默认医疗机构编码 = "522633020000001";

        /// <summary>
        /// 执行HIS操作
        /// </summary>
        /// <param name="strClientID">客户端标识</param>
        /// <param name="strOptionCode">功能编码</param>
        /// <param name="strHospitalCode">医疗机构编码</param>
        /// <param name="strParam">业务参数</param>
        /// <returns></returns>
        public static string ExecHisOption(string strClientID, string strOptionCode,
            string strHospitalCode, string strParam)
        {
            if (string.IsNullOrEmpty(strHospitalCode))
            {
                strHospitalCode = Str默认医疗机构编码;
            }
            //($"4499|123456|{bp.openid}|1004|522633020000001|本人|崔景顺|1|1983-03-15|211402198303150228|13800000001");
            return new HisData.QueryHisDataSoapClient().QueryData($"{Str平台标识}|{Str认证密钥}|{strClientID}|{strOptionCode}|{strHospitalCode}|{strParam}");
        }
    }
}
