﻿/*----------------------------------------------------------------
// Copyright (C) 2019  版权所有。 
//
// 文件名：IBaseService
// 文件功能描述：
// 
// 创建者：名字 (admin)
// 时间：2020-04-26 13:14:53
//
// 修改人：
// 时间：
// 修改说明：
//
// 版本：V1.0.0
//----------------------------------------------------------------*/
using IDAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IBLL
{
    public interface IBaseService<T> where T : class, new()
    {
        IDBSession DbSession { get; }

        IBaseDal<T> CurrentDal { get; set; }


        IQueryable<T> LoadEntities();
        IQueryable<T> LoadEntities(System.Linq.Expressions.Expression<Func<T, bool>> whereLambda);


        IQueryable<T> LoadEntities<s>(int pageIndex, int pageSize, out int totalCount, System.Linq.Expressions.Expression<Func<T, s>> orderbyLambda, bool isAsc);
        IQueryable<T> LoadEntities<s>(int pageIndex, int pageSize, out int totalCount, System.Linq.Expressions.Expression<Func<T, bool>> whereLambda, System.Linq.Expressions.Expression<Func<T, s>> orderbyLambda, bool isAsc);

        T LoadEntity(System.Linq.Expressions.Expression<Func<T, bool>> whereLambda);

        bool DeleteEntity(T entity);

        bool UpdateEntity(T entity);
        T AddEntity(T entity);
    }
}
