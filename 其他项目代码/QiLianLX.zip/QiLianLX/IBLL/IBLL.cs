﻿
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IBLL
{
    public partial interface Ijc_qyService : IBaseService<jc_qy>
    {
    }
    public partial interface Ijc_qy_cpService : IBaseService<jc_qy_cp>
    {
    }
    public partial interface Ijc_yhService : IBaseService<jc_yh>
    {
    }
    public partial interface Ijc_yh_cpService : IBaseService<jc_yh_cp>
    {
    }
    public partial interface Ijc_yh_qyService : IBaseService<jc_yh_qy>
    {
    }
    public partial interface Iyw_kcService : IBaseService<yw_kc>
    {
    }
    public partial interface Iyw_mxService : IBaseService<yw_mx>
    {
    }
}
