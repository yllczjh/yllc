﻿using DALFactory;
using IDAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public abstract class BaseService<T> where T : class, new()
    {
        public IDBSession DbSession
        {
            get { return new DBSession(); }
        }

        public IBaseDal<T> CurrentDal { get; set; }

        public abstract void SetCurrentDal();

        public BaseService()
        {
            SetCurrentDal();
        }

        public IQueryable<T> LoadEntitis(System.Linq.Expressions.Expression<Func<T, bool>> whereLambda)
        {
            return CurrentDal.LoadEntitis(whereLambda);
        }

        public IQueryable<T> LoadEntities()
        {
            return this.CurrentDal.LoadEntitis(T => true);
        }

        public IQueryable<T> LoadEntities(System.Linq.Expressions.Expression<Func<T, bool>> whereLambda)
        {
            return this.CurrentDal.LoadEntitis(whereLambda);
        }

        public IQueryable<T> LoadEntities<s>(int pageIndex, int pageSize, out int totalCount, System.Linq.Expressions.Expression<Func<T, s>> orderbyLambda, bool isAsc)
        {
            //return CurrentDal.LoadPageEntities<s>(pageIndex, pageSize, out totalCount, orderbyLambda, isAsc);
            return this.LoadEntities<s>(pageIndex, pageSize, out totalCount, T => true, orderbyLambda, isAsc);
        }

        public IQueryable<T> LoadEntities<s>(int pageIndex, int pageSize, out int totalCount, System.Linq.Expressions.Expression<Func<T, bool>> whereLambda, System.Linq.Expressions.Expression<Func<T, s>> orderbyLambda, bool isAsc)
        {
            return CurrentDal.LoadPageEntities<s>(pageIndex, pageSize, out totalCount, whereLambda, orderbyLambda, isAsc);
        }


        public T LoadEntity(System.Linq.Expressions.Expression<Func<T, bool>> whereLambda)
        {
            return LoadEntitis(whereLambda).FirstOrDefault();
        }

        public bool DeleteEntity(T entity)
        {
            CurrentDal.DeleteEntity(entity);
            return DbSession.SaveChanges();
        }

        public bool UpdateEntity(T entity)
        {
            CurrentDal.UpdateEntity(entity);
            return DbSession.SaveChanges();
        }
        public T AddEntity(T entity)
        {
            CurrentDal.AddEntity(entity);

            DbSession.SaveChanges();
            return entity;
        }
    }
}
