﻿/*----------------------------------------------------------------
// Copyright (C) 2019  版权所有。 
//
// 文件名：MenuService
// 文件功能描述：
// 
// 创建者：名字 (admin)
// 时间：2020-09-26 00:24:08
//
// 修改人：
// 时间：
// 修改说明：
//
// 版本：V1.0.0
//----------------------------------------------------------------*/
using IBLL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
   public partial class MenuService : BaseService<Menu>,IMenuService
    {
        //protected override void SetCurrentDal()
        //{
        //    this.CurrentDal = this.DbSession.MenuDal;
        //}

        //public List<S_reportParam> GetReportParams(string mId)
        //{

        //}
    }
}
