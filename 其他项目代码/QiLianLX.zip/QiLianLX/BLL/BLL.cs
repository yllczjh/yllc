﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IBLL;
using Model;

namespace BLL
{
    public partial class jc_qyService : BaseService<jc_qy>, Ijc_qyService
    {
        public override void SetCurrentDal()
        {
            this.CurrentDal = DbSession.jc_qyDal;
        }
    }
    public partial class jc_qy_cpService : BaseService<jc_qy_cp>, Ijc_qy_cpService
    {
        public override void SetCurrentDal()
        {
            this.CurrentDal = DbSession.jc_qy_cpDal;
        }
    }
    public partial class jc_yhService : BaseService<jc_yh>, Ijc_yhService
    {
        public override void SetCurrentDal()
        {
            this.CurrentDal = DbSession.jc_yhDal;
        }
    }
    public partial class jc_yh_cpService : BaseService<jc_yh_cp>, Ijc_yh_cpService
    {
        public override void SetCurrentDal()
        {
            this.CurrentDal = DbSession.jc_yh_cpDal;
        }
    }
    public partial class jc_yh_qyService : BaseService<jc_yh_qy>, Ijc_yh_qyService
    {
        public override void SetCurrentDal()
        {
            this.CurrentDal = DbSession.jc_yh_qyDal;
        }
    }
    public partial class yw_kcService : BaseService<yw_kc>, Iyw_kcService
    {
        public override void SetCurrentDal()
        {
            this.CurrentDal = DbSession.yw_kcDal;
        }
    }
    public partial class yw_mxService : BaseService<yw_mx>, Iyw_mxService
    {
        public override void SetCurrentDal()
        {
            this.CurrentDal = DbSession.yw_mxDal;
        }
    }
}
