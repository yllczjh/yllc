﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp.WxPayApiV3.lib
{
    public class WxPayException : Exception
    {
        public WxPayException(string msg) : base(msg)
        {

        }
    }
}