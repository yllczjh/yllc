﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApp.WxPayApiV3.lib;

namespace WebApp.WxPayApiV3.business
{
    public class Refund
    {
        /***
        * 申请退款完整业务流程逻辑
        * @param transaction_id 微信订单号（优先使用）
        * @param out_trade_no 商户订单号
        * @param total_fee 订单总金额
        * @param refund_fee 退款金额
        * @return 退款结果（json格式）
        */
        /// <summary>
        /// 申请退款完整业务流程逻辑
        /// </summary>
        /// <param name="transaction_id">微信订单号（优先使用）</param>
        /// <param name="out_trade_no">商户订单号</param>
        /// <param name="total_fee">订单总金额</param>
        /// <param name="refund_fee">退款金额</param>
        /// <returns>退款结果(json格式）</returns>
        //public static string Run(string transaction_id, string out_trade_no, string total_fee, string refund_fee)
        public static WxPayData Run(string transaction_id, string out_trade_no, string total_fee, string refund_fee, string refund_no)
        {
            Log.Info("Refund", "Refund is processing...");

            WxPayData data = new WxPayData();
            if (!string.IsNullOrEmpty(transaction_id))//微信订单号存在的条件下，则已微信订单号为准
            {
                data.SetValue("transaction_id", transaction_id);
            }
            else//微信订单号不存在，才根据商户订单号去退款
            {
                data.SetValue("out_trade_no", out_trade_no);
            }
            Newtonsoft.Json.Linq.JObject amount = new Newtonsoft.Json.Linq.JObject();
            amount.Add("refund", int.Parse(refund_fee));//退款金额
            amount.Add("total", int.Parse(total_fee));//订单总金额
            amount.Add("currency", "CNY");//退款币种

            data.SetValue("out_refund_no", refund_no);//随机生成商户退款单号
            if (!data.IsSet("notify_url"))
                data.SetValue("notify_url", WxPayConfig.GetConfig().GetRefundNotifyUrl());
            //data.SetValue("out_refund_no", lib.WxPayApiV3.GenerateOutTradeNo());//随机生成商户退款单号
            //data.SetValue("op_user_id", WxPayConfig.GetConfig().GetMchID());//操作员，默认为商户号
            data.SetValue("amount", amount);//订单金额信息

            WxPayData result = lib.WxPayApiV3.Refund(data);//提交退款申请给API，接收返回数据

            if (result.IsSet("refund_id"))
                SaveRefund(result);

            Log.Info("Refund", "Refund process complete, result : " + result.ToJsonByNewton());
            //return result.ToPrintStr();
            return result;
        }

        private static bool SaveRefund(WxPayData refund)
        {
            if (!refund.IsSet("refund_id"))
                throw new WxPayException(refund.ToJsonByNewton());
            IBLL.IWxpayRefundService service = new BLL.WxpayRefundService();

            string refund_id = refund.GetValue("refund_id").ToString();
            Model.WxpayRefund model = service.LoadEntity(t => t.refund_id == refund_id);

            if (model == null)
                model = new Model.WxpayRefund();
            model.out_refund_no = refund.GetValue("out_refund_no").ToString();
            model.transaction_id = refund.GetValue("transaction_id").ToString();
            model.out_trade_no = refund.GetValue("out_trade_no").ToString();
            model.channel = refund.GetValue("channel").ToString();
            model.user_received_account = refund.GetValue("user_received_account").ToString();
            model.create_time = refund.GetValue("create_time").ToString();
            model.status = refund.GetValue("status").ToString();

            WxPayData amount = new WxPayData();
            amount.FromJson(refund.GetValue("amount").ToString());
            model.amount_total = int.Parse(amount.GetValue("total").ToString());
            model.amount_refund = int.Parse(amount.GetValue("refund").ToString());
            model.amount_payer_total = int.Parse(amount.GetValue("payer_total").ToString());
            model.amount_payer_refund = int.Parse(amount.GetValue("payer_refund").ToString());
            model.amount_settlement_refund = int.Parse(amount.GetValue("settlement_refund").ToString());
            model.amount_settlement_total = int.Parse(amount.GetValue("settlement_total").ToString());
            model.amount_discount_refund = int.Parse(amount.GetValue("discount_refund").ToString());
            model.amount_currency = amount.GetValue("currency").ToString();

            if (refund.IsSet("success_time"))
                model.success_time = refund.GetValue("success_time").ToString();
            if (refund.IsSet("funds_account"))
                model.funds_account = refund.GetValue("funds_account").ToString();
            if (string.IsNullOrEmpty(model.refund_id))
            {
                model.refund_id = refund.GetValue("refund_id").ToString();
                model = service.AddEntity(model);
                return model != null;
            }
            else
            {
                return service.UpdateEntity(model);
            }
        }
    }
}