﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApp.WxPayApiV3.lib;

namespace WebApp.WxPayApiV3.business
{
    public class RefundQuery
    {
        /***
        * 退款查询完整业务流程逻辑
        * @param refund_id 微信退款单号（优先使用）
        * @param out_refund_no 商户退款单号
        * @param transaction_id 微信订单号
        * @param out_trade_no 商户订单号
        * @return 退款查询结果（xml格式）
        */
        /// <summary>
        /// 退款查询
        /// </summary>
        /// <param name="out_refund_no">商户退款单号</param>
        /// <returns></returns>
        public static WxPayData Run(string out_refund_no)
        {
            Log.Info("RefundQuery", "RefundQuery is processing...");

            WxPayData data = new WxPayData();
            if (!string.IsNullOrEmpty(out_refund_no))
            {
                data.SetValue("out_refund_no", out_refund_no);//商户退款单号
            }


            WxPayData result = lib.WxPayApiV3.RefundQuery(data);//提交退款查询给API，接收返回数据

            SaveRefund(result);

            Log.Info("RefundQuery", "RefundQuery process complete, result : " + result.ToJsonByNewton());
            return result;//.ToPrintStr();
        }

        private static bool SaveRefund(WxPayData refund)
        {
            if (!refund.IsSet("refund_id"))
                throw new WxPayException(refund.ToJsonByNewton());
            IBLL.IWxpayRefundService service = new BLL.WxpayRefundService();

            string refund_id = refund.GetValue("refund_id").ToString();
            Model.WxpayRefund model = service.LoadEntity(t => t.refund_id == refund_id);

            if (model == null)
                model = new Model.WxpayRefund();
            model.out_refund_no = refund.GetValue("out_refund_no").ToString();
            model.transaction_id = refund.GetValue("transaction_id").ToString();
            model.out_trade_no = refund.GetValue("out_trade_no").ToString();
            model.channel = refund.GetValue("channel").ToString();
            model.user_received_account = refund.GetValue("user_received_account").ToString();
            model.create_time = refund.GetValue("create_time").ToString();
            model.status = refund.GetValue("status").ToString();

            WxPayData amount = new WxPayData();
            amount.FromJson(refund.GetValue("amount").ToString());
            model.amount_total = int.Parse(amount.GetValue("total").ToString());
            model.amount_refund = int.Parse(amount.GetValue("refund").ToString());
            model.amount_payer_total = int.Parse(amount.GetValue("payer_total").ToString());
            model.amount_payer_refund = int.Parse(amount.GetValue("payer_refund").ToString());
            model.amount_settlement_refund = int.Parse(amount.GetValue("settlement_refund").ToString());
            model.amount_settlement_total = int.Parse(amount.GetValue("settlement_total").ToString());
            model.amount_discount_refund = int.Parse(amount.GetValue("discount_refund").ToString());
            model.amount_currency = amount.GetValue("currency").ToString();

            if (refund.IsSet("success_time"))
                model.success_time = refund.GetValue("success_time").ToString();
            if (refund.IsSet("funds_account"))
                model.funds_account = refund.GetValue("funds_account").ToString();
            if (string.IsNullOrEmpty(model.refund_id))
            {
                model.refund_id = refund.GetValue("refund_id").ToString();
                model = service.AddEntity(model);
                return model != null;
            }
            else
            {
                return service.UpdateEntity(model);
            }
        }
    }
}