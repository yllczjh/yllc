﻿/*----------------------------------------------------------------
// Copyright (C) 2019  版权所有。 
//
// 文件名：JsApiPay
// 文件功能描述：
// 
// 创建者：名字 (admin)
// 时间：2021-01-14 13:59:19
//
// 修改人：
// 时间：
// 修改说明：
//
// 版本：V1.0.0
//----------------------------------------------------------------*/
using LitJson;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Security;
using WebApp.WxPayApiV3.lib;

namespace WebApp.WxPayApiV3.business
{
    public class JsApiPay
    {
        /// <summary>
        /// 保存页面对象，因为要在类的方法中使用Page的Request对象
        /// </summary>
        //private Page page { get; set; }
        private System.Web.HttpRequestBase request { get; set; }

        /// <summary>
        /// openid用于调用统一下单接口
        /// </summary>
        public string openid { get; set; }

        /// <summary>
        /// access_token用于获取收货地址js函数入口参数
        /// </summary>
        public string access_token { get; set; }

        /// <summary>
        /// 商品金额，用于统一下单
        /// </summary>
        public int total_fee { get; set; }

        /// <summary>
        /// 统一下单接口返回结果
        /// </summary>
        public WxPayData unifiedOrderResult { get; set; }

        //public JsApiPay(Page page)
        //{
        //    this.page = page;
        //}
        public JsApiPay(System.Web.HttpRequestBase request)
        {
            this.request = request;
        }
        public void GetOpenidAndAccessToken()
        {
            if (!string.IsNullOrEmpty(request.QueryString["code"]))
            {
                //获取code码，以获取openid和access_token
                string code = request.QueryString["code"];
                //Log.Debug(this.GetType().ToString(), "Get code : " + code);
                GetOpenidAndAccessTokenFromCode(code);
            }
            else
            {
                //构造网页授权获取code的URL
                string host = request.Url.Host;
                string path = request.Path;
                string redirect_uri = HttpUtility.UrlEncode("http://" + host + path);
                WxPayData data = new WxPayData();
                data.SetValue("appid", WxPayConfig.GetConfig().GetAppID());
                data.SetValue("redirect_uri", redirect_uri);
                data.SetValue("response_type", "code");
                data.SetValue("scope", "snsapi_base");
                data.SetValue("state", "STATE" + "#wechat_redirect");
                string url = "https://open.weixin.qq.com/connect/oauth2/authorize?" + data.ToUrl();
                Log.Debug(this.GetType().ToString(), "Will Redirect to URL : " + url);
                try
                {
                    //触发微信返回code码         
                    request.RequestContext.HttpContext.Response.Redirect(url);//Redirect函数会抛出ThreadAbortException异常，不用处理这个异常
                }
                catch (System.Threading.ThreadAbortException ex)
                {
                }
            }
        }


        /**
	    * 
	    * 通过code换取网页授权access_token和openid的返回数据，正确时返回的JSON数据包如下：
	    * {
	    *  "access_token":"ACCESS_TOKEN",
	    *  "expires_in":7200,
	    *  "refresh_token":"REFRESH_TOKEN",
	    *  "openid":"OPENID",
	    *  "scope":"SCOPE",
	    *  "unionid": "o6_bmasdasdsad6_2sgVt7hMZOPfL"
	    * }
	    * 其中access_token可用于获取共享收货地址
	    * openid是微信支付jsapi支付接口统一下单时必须的参数
        * 更详细的说明请参考网页授权获取用户基本信息：http://mp.weixin.qq.com/wiki/17/c0f37d5704f0b64713d5d2c37b468d75.html
        * @失败时抛异常WxPayException
	    */
        public void GetOpenidAndAccessTokenFromCode(string code)
        {
            try
            {
                //构造获取openid及access_token的url
                WxPayData data = new WxPayData();
                data.SetValue("appid", WxPayConfig.GetConfig().GetAppID());
                data.SetValue("secret", WxPayConfig.GetConfig().GetAppSecret());
                data.SetValue("code", code);
                data.SetValue("grant_type", "authorization_code");
                string url = "https://api.weixin.qq.com/sns/oauth2/access_token?" + data.ToUrl();

                //请求url以获取数据
                string result = HttpService.Get(url);
                //string result = "{\"access_token\":\"41_dYad3KTmXUsxA5f9v_fIndHJHBcymroUsU_8Sd9NbyUriC7CGkLrf9uln2nLLiPehOvT9hOKGPSG5l8evSfz6A\",\"expires_in\":7200,\"refresh_token\":\"41_lSIuo97VAULsum-zlwACZ2x3PjtjEF_PM2oj4z4sjnzEaRx0bQ7jvHroZ60afWpjrd-WL0rNKBZzsjtBKE6dKg\",\"openid\":\"oHQPu0sVahm36H1HsaMlJ-fUb4YE\",\"scope\":\"snsapi_userinfo\"}";
                Log.Debug(this.GetType().ToString(), "GetOpenidAndAccessTokenFromCode response : " + result);

                //保存access_token，用于收货地址获取
                JsonData jd = JsonMapper.ToObject(result);

                if (((System.Collections.IDictionary)jd).Contains("errcode"))
                    throw new Exception($"请求微信用户信息错误,errcode:{jd["errcode"].ToString()}:errmsg:{jd["errmsg"].ToString()}");

                access_token = (string)jd["access_token"];

                //获取用户openid
                openid = (string)jd["openid"];

                Log.Debug(this.GetType().ToString(), "Get openid : " + openid);
                Log.Debug(this.GetType().ToString(), "Get access_token : " + access_token);
            }
            catch (Exception ex)
            {
                Log.Error(this.GetType().ToString(), ex.ToString());
                throw new WxPayException(ex.ToString());
            }
        }

        /**
         * 调用统一下单，获得下单结果
         * @return 统一下单结果
         * @失败时抛异常WxPayException
         */
        public WxPayData GetUnifiedOrderResult()
        {
            string ddh = request.Params["ddh"];
            if (string.IsNullOrEmpty(ddh))
                throw new WxPayException("统一下单校验失败!本地订单号不允许为空");
            IBLL.IHisYuYueGuaHaoService service = new BLL.HisYuYueGuaHaoService();
            Model.HisYuYueGuaHao dd = service.LoadEntities(y => y.ddh == ddh).FirstOrDefault();

            if (!string.IsNullOrEmpty(dd.prepay_id))
            {
                WxPayData res = new WxPayData();
                res.SetValue("prepay_id", dd.prepay_id);
                return res;
            }
            //统一下单
            WxPayData data = new WxPayData();
            Newtonsoft.Json.Linq.JObject amount = new Newtonsoft.Json.Linq.JObject();
            /**
             * 应用ID appid 
             * 直连商户号 mchid 在下单接口统一处理
             */
            data.SetValue("description", "预约订单");
            data.SetValue("out_trade_no", dd.ddh);//商户订单号
            /***
             * 订单失效时间，遵循rfc3339标准格式，格式为YYYY-MM-DDTHH:mm:ss+TIMEZONE，YYYY-MM-DD表示年月日，
             * T出现在字符串中，表示time元素的开头，HH:mm:ss表示时分秒，
             * TIMEZONE表示时区（+08:00表示东八区时间，领先UTC 8小时，即北京时间）。
             * 例如：2015-05-20T13:29:35+08:00表示，北京时间2015年5月20日 13点29分35秒。
             */
            data.SetValue("time_expire", dd.gqsj.ToString("yyyy-MM-ddTHH:mm:sszzz"));//交易结束时间

            data.SetValue("attach", "test");//附加数据
            //data.SetValue("goods_tag", "test");//订单优惠标记，可空
            //amount.SetValue("currency", "CNY");
            //amount.SetValue("total", total_fee);
            amount.Add("currency", "CNY");
            amount.Add("total", total_fee);
            data.SetValue("amount", amount);
            //WxPayData payer = new WxPayData();
            Newtonsoft.Json.Linq.JObject payer = new Newtonsoft.Json.Linq.JObject();
            payer.Add("openid", openid);
            data.SetValue("payer", payer);
            //data.SetValue("")
            //data.SetValue("body", "test");
            //data.SetValue("total_fee", total_fee);
            //data.SetValue("time_start", DateTime.Now.ToString("yyyyMMddHHmmss"));
            //data.SetValue("trade_type", "JSAPI");

            WxPayData result = lib.WxPayApiV3.UnifiedOrder(data);
            if (!result.IsSet("prepay_id") || result.GetValue("prepay_id").ToString() == "")//!result.IsSet("appid") ||
            {
                Log.Error(this.GetType().ToString(), "UnifiedOrder response error!");
                throw new WxPayException("UnifiedOrder response error!" + result.ToJsonByNewton());
            }
            dd.prepay_id = result.GetValue("prepay_id").ToString();
            if (!service.UpdateEntity(dd))
            {
                Log.Debug(this.GetType().ToString(), "保存预支付订单出错！");
                throw new WxPayException("下单失败" + LitJson.JsonMapper.ToJson(dd));
            }
            unifiedOrderResult = result;
            return result;
        }

        /**
         * 调用统一下单，获得下单结果
         * @return 统一下单结果
         * @失败时抛异常WxPayException
         */
        public WxPayData GetUnifiedOrderResult_V3()
        {
            string ddh = request.Params["ddh"];
            if (string.IsNullOrEmpty(ddh))
                throw new WxPayException("统一下单校验失败!本地订单号不允许为空");
            IBLL.IBusTradeService service = new BLL.BusTradeService();
            Model.BusTrade dd = service.LoadEntity(y => y.his_trade_no == ddh);
            if(dd==null)
            {
                //TODO:获取本地订单失败处理
            }

            if (!string.IsNullOrEmpty(dd.prepay_id))
            {
                WxPayData res = new WxPayData();
                res.SetValue("prepay_id", dd.prepay_id);
                return res;
            }
            //统一下单
            WxPayData data = new WxPayData();
            Newtonsoft.Json.Linq.JObject amount = new Newtonsoft.Json.Linq.JObject();
            /**
             * 应用ID appid 
             * 直连商户号 mchid 在下单接口统一处理
             */
            data.SetValue("description", "预约订单");
            data.SetValue("out_trade_no", dd.his_trade_no);//商户订单号
            /***
             * 订单失效时间，遵循rfc3339标准格式，格式为YYYY-MM-DDTHH:mm:ss+TIMEZONE，YYYY-MM-DD表示年月日，
             * T出现在字符串中，表示time元素的开头，HH:mm:ss表示时分秒，
             * TIMEZONE表示时区（+08:00表示东八区时间，领先UTC 8小时，即北京时间）。
             * 例如：2015-05-20T13:29:35+08:00表示，北京时间2015年5月20日 13点29分35秒。
             */
            data.SetValue("time_expire", dd.his_expire_time.Value.ToString("yyyy-MM-ddTHH:mm:sszzz"));//交易结束时间

            data.SetValue("attach", "test");//附加数据
            //data.SetValue("goods_tag", "test");//订单优惠标记，可空
            //amount.SetValue("currency", "CNY");
            //amount.SetValue("total", total_fee);
            amount.Add("currency", "CNY");
            amount.Add("total", total_fee);
            data.SetValue("amount", amount);
            //WxPayData payer = new WxPayData();
            Newtonsoft.Json.Linq.JObject payer = new Newtonsoft.Json.Linq.JObject();
            payer.Add("openid", openid);
            data.SetValue("payer", payer);
            //data.SetValue("")
            //data.SetValue("body", "test");
            //data.SetValue("total_fee", total_fee);
            //data.SetValue("time_start", DateTime.Now.ToString("yyyyMMddHHmmss"));
            //data.SetValue("trade_type", "JSAPI");

            WxPayData result = lib.WxPayApiV3.UnifiedOrder(data);
            if (!result.IsSet("prepay_id") || result.GetValue("prepay_id").ToString() == "")//!result.IsSet("appid") ||
            {
                Log.Error(this.GetType().ToString(), "UnifiedOrder response error!");
                throw new WxPayException("UnifiedOrder response error!" + result.ToJsonByNewton());
            }
            dd.prepay_id = result.GetValue("prepay_id").ToString();
            if (!service.UpdateEntity(dd))
            {
                Log.Debug(this.GetType().ToString(), "保存预支付订单出错！");
                throw new WxPayException("下单失败" + LitJson.JsonMapper.ToJson(dd));
            }
            unifiedOrderResult = result;
            return result;
        }


        /**
	    * 
	    * 获取收货地址js函数入口参数,详情请参考收货地址共享接口：http://pay.weixin.qq.com/wiki/doc/api/jsapi.php?chapter=7_9
	    * @return string 共享收货地址js函数需要的参数，json格式可以直接做参数使用
	    */
        public string GetEditAddressParameters()
        {
            string parameter = "";
            try
            {
                string host = request.Url.Host;
                string path = request.Path;
                string queryString = request.Url.Query;
                //这个地方要注意，参与签名的是网页授权获取用户信息时微信后台回传的完整url
                string url = "http://" + host + path + queryString;

                //构造需要用SHA1算法加密的数据
                WxPayData signData = new WxPayData();
                signData.SetValue("appid", WxPayConfig.GetConfig().GetAppID());
                signData.SetValue("url", url);
                signData.SetValue("timestamp", lib.WxPayApiV3.GenerateTimeStamp());
                signData.SetValue("noncestr", lib.WxPayApiV3.GenerateNonceStr());
                signData.SetValue("accesstoken", access_token);
                string param = signData.ToUrl();

                Log.Debug(this.GetType().ToString(), "SHA1 encrypt param : " + param);
                //SHA1加密
                string addrSign = FormsAuthentication.HashPasswordForStoringInConfigFile(param, "SHA1");
                Log.Debug(this.GetType().ToString(), "SHA1 encrypt result : " + addrSign);

                //获取收货地址js函数入口参数
                WxPayData afterData = new WxPayData();
                afterData.SetValue("appId", WxPayConfig.GetConfig().GetAppID());
                afterData.SetValue("scope", "jsapi_address");
                afterData.SetValue("signType", "sha1");
                afterData.SetValue("addrSign", addrSign);
                afterData.SetValue("timeStamp", signData.GetValue("timestamp"));
                afterData.SetValue("nonceStr", signData.GetValue("noncestr"));

                //转为json格式
                parameter = afterData.ToJson();
                Log.Debug(this.GetType().ToString(), "Get EditAddressParam : " + parameter);
            }
            catch (Exception ex)
            {
                Log.Error(this.GetType().ToString(), ex.ToString());
                throw new WxPayException(ex.ToString());
            }

            return parameter;
        }





    }//class JsApiPay end
}
