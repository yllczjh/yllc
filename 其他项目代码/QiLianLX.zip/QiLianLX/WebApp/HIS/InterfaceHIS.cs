﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Utils;

namespace WebApp.HIS
{
    public class InterfaceHIS
    {
        /// <summary>
        /// 门诊_取消预约挂号申请
        /// </summary>
        /// <param name="srcOrder">原订单信息</param>
        /// <returns></returns>
        //public ResultStruct MZ_QuXiaoYuYueGuaHaoShenQing(string ddh)
        //{
        //} 
        public static ResultStruct MZ_QuXiaoYuYueGuaHaoShenQing(WxPayApiV3.lib.WxPayData srcOrder)
        {
            //TODO:此处应是参数必填校验


            //string StrOpenid = GetRequestString("openid", Request);
            //string StrBrid = GetRequestString("brid", Request);
            //string StrYydh = GetRequestString("yydh", Request);
            //string StrDdh = GetRequestString("ddh", Request);
            //string StrPttkh = GetRequestString("pttkh", Request);//平台退款号
            //string StrPttksj = GetRequestString("pttksj", Request);
            string StrBrid = srcOrder.GetValue("brid").ToString();
            string StrYydh = srcOrder.GetValue("yydh").ToString();
            string StrDdh = srcOrder.GetValue("ddh").ToString();
            string StrPttkh = srcOrder.GetValue("pttkh").ToString();//平台退款号
            string StrPttksj = srcOrder.GetValue("pttksj").ToString();

            //string strData = SupportTools.HisDataHelper.ExecHisOption(StrOpenid, "1011", "", $"{StrBrid}|{StrYydh}|{StrDdh}|{StrPttkh}|{StrPttksj}");
            //Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData);
            return Run(srcOrder.GetValue("openid").ToString(), "1011", "", $"{StrBrid}|{StrYydh}|{StrDdh}|{StrPttkh}|{StrPttksj}");
        }

        public static ResultStruct MZ_DingDanShengCheng(WxPayApiV3.lib.WxPayData param)
        {
            //TODO:此处应是参数必填校验

            string openid = param.GetValue("openid").ToString();
            string StrBrid = param.GetValue("brid").ToString();
            string StrMzblh = param.GetValue("mzblh").ToString();//门诊病历号
            string StrSfxh = param.GetValue("sfxh").ToString();//收费序号，由缴费申请1013生成

            return Run(openid, "1014", "", $"{StrBrid}|{ StrMzblh}|{StrSfxh}");
        }
        public static ResultStruct MZ_HeSuanJianCeYuYue(WxPayApiV3.lib.WxPayData param)
        {
            //TODO:此处应是参数必填校验

            string openid = param.GetValue("openid").ToString();
            string StrBrid = param.GetValue("brid").ToString();

            return Run(openid, "2001", "", $"{StrBrid}");
        }

        public static ResultStruct TradeRefund(Model.BusTrade srcBusTrade, Model.BusRefund busRefund)
        {
            if (srcBusTrade.trade_type == Model.Enum.BusEnum.OrderType.门诊挂号.ToString())
            {
                IBLL.IHisYuYueGuaHaoService service = new BLL.HisYuYueGuaHaoService();
                Model.HisYuYueGuaHao trade = service.LoadEntity(t => t.ddh == srcBusTrade.id_no);
                WxPayApiV3.lib.WxPayData hisInobj = new WxPayApiV3.lib.WxPayData();
                hisInobj.SetValue("openid", trade.openid);
                hisInobj.SetValue("brid", trade.brid);
                hisInobj.SetValue("yydh", trade.yydh);
                hisInobj.SetValue("ddh", trade.ddh);
                hisInobj.SetValue("pttkh", busRefund.refund_no);
                hisInobj.SetValue("pttksj", busRefund.create_time);

                //return Run("openid", "", "", "");
                return MZ_QuXiaoYuYueGuaHaoShenQing(hisInobj);
            }
            else
            {
                ResultStruct rs = new ResultStruct();
                rs.Code = "0";
                rs.Info = "无接口，默认成功！";
                return rs;
            }
        }

        private static ResultStruct Run(string strClientID, string strOptionCode,
            string strHospitalCode, string strParam)
        {
            string strData = SupportTools.HisDataHelper.ExecHisOption(strClientID, strOptionCode, strHospitalCode, strParam);
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData);
            return rs;
        }
    }
}