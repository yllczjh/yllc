﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp.Models
{
    public class MenuItem
    {
        public Menu menu { get; set; }

        public List<MenuItem> child { get; set; }
    }
}