﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApp.WxPayApiV3.lib;

namespace WebApp.Controllers
{
    public class TestController : BaseController
    {
        // GET: Test
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Post()
        {
            string mothed = GetRequestString("mothed");
            if (mothed == "payNotify") {
                return Json(payNotify(), JsonRequestBehavior.AllowGet);
            }
            WxPayData data = new WxPayData();
            data.SetValue("id", "f8a2925e-4efc-5b7c-ba45-617bfccc7a7f");
            data.SetValue("create_time", "2021-03-16T16:48:32+08:00");
            data.SetValue("resource_type", "encrypt-resource");
            data.SetValue("event_type", "REFUND.SUCCESS");
            data.SetValue("summary", "退款成功");

            Dictionary<string, string> child = new Dictionary<string, string>();
            child.Add("original_type", "refund");
            child.Add("algorithm", "AEAD_AES_256_GCM");
            child.Add("ciphertext", "RvwP84uH4ysGHRnx8q7LJs5tx0ON52tnaSwlam3ixAU277Rxm6EhN9CWNqhtE3WPMNamayko+oiqKrOSTiT/0f4870jcC3TVsuq8x1Hmhu+FATNmhdUjGFYcXJO9+Z7KfvTe93ClUYTiYBPEYoFBdAi4w05cE+prH5pDkQJ7X3th6eo9E+qThLhDXI63s8Xm0zsVY8ZTfc4ytAmxmNfGn3vNXOP5g+5/NBt4h7UxxfEYdDbWNJGSO8N5gkNaI0dYWkDrALk8arhWyfe06tDw+r9U8BDYRwI5TAlMBuiaI4v6ouoapC9dWFK9GN9p325tw/vQe/azgbuF9fkujDVhdNpDMgGwsBYZyS8SpqlZqWEHGc7vpmxIe5nbxX8us4P0NpwKpNYHBm1FzRcsz6Pr+TzF/iot4FOWzejbbcEtBc2GHpi0WHnzMhZoVjZVv8aZb+TcJ8G3XRJwj+bluVpcjH+dUcQGy+ViRbTHMQgWljLe6Um+M4sT8uqdjA==");
            child.Add("associated_data", "refund");
            child.Add("nonce", "uaJahNDr4QOe");

            data.SetValue("resource", child);

            string json = data.ToJsonByNewton();
            string strdata = HttpService.Post(json, "http://127.0.0.1:3877/bus/refundnotify", false, 6);
            //string strdata = HttpService.Post(data.ToJsonByNewton(), "https://test6.ql-soft.com/bus/refundnotify", false, 6);
            return Json(strdata, JsonRequestBehavior.AllowGet);
        }
        private string payNotify()
        {
            WxPayData data = new WxPayData();
            data.SetValue("id", "f8a2925e-4efc-5b7c-ba45-617bfccc7a7f");
            data.SetValue("create_time", "2021-03-16T16:48:32+08:00");
            data.SetValue("resource_type", "encrypt-resource");
            data.SetValue("event_type", "TRANSACTION.SUCCESS");
            data.SetValue("summary", "支付成功");

            Dictionary<string, string> child = new Dictionary<string, string>();
            child.Add("original_type", "transaction");
            child.Add("algorithm", "AEAD_AES_256_GCM");
            child.Add("ciphertext", "RvwW4oKA9GhfS0GorMSUdt9h3EGd+n4/KWpPLi6xkFFdsexjkrAjNNOUM6h/Dm/ZbpWpdSc+4JXnfpfZWme8lrhRqxeYWijPsey+x0/1wrPAVm1witMjH00ICt/tp9nLaPmjvzeAarOkE1/bIcIGN2HrgwoaRbIxVYpJgXAFNWgq9P5kSLHJ0qNJXJOn8pCwlmVADJYVc9Zk81jmzbmH2y2MDvPzk4waRGkL5NEi3ONKIW+EWdfJZ4Qp3QdsAGAlBRb6BqMiJ/Yd9cyozfDXyPQU8Fn2X0M9UhVmHPXVfJjwsPQI4XsTAADkWYhEsTs4mbeYIabtxead//kggnRvbMVZMir77k8Bn3FW/vBKqnIHGc/pr2lDPYHDsx9DgaPBccJ3vdwBBGkGmVJfjrzk9Cvewy084wTCmebDMt1sQprPWQ9mv/kD1pmdk388/InYb+XaNpHSHJuKVHA3Q8i8Qbsv1gG/HnmChvPU9q6shRhmRPi4zFbj9s1kWpTGNKNMFzl2qmnAE0d7sA45Mtc0bgMdlsFcyOyu+0tH292cXrIuOPPrgLU/LEOAkz3HRiDLMC/T3PQppLV5+K4eUOzyeS17TCHsLdaQGbSN/kilCaB2zGWAzsq+gno0iD3cFcGh8trpu84SqMPi+DPlCxUAy56h9LGk83wx4QoYYOPIV2QbVLIIu03sLKdBpUr/ymgA6Uh8aSrSwkISOgmwrSmDkxHkTfcnqysImpUEMqA1Vcrm3nAoHWWx5BLlRH0lvnajIJP1ZTLj5Ugb/zr1VyR1iywtuuy4gouC0GHmkg7efKerYdDAmFFn2+vjysb0AK2hhI68e201dQOPafpKeKZvT34OJ+st0u8p75mAX9DnvvEuUYpR3zXh+N+GhZ4az6H8yPuEHAycXTY7SJa3ePawDfMf0Y9OQLbqLrKg3rVV3BEqT9gRQFHIjB/XpHZwfh3RMESUpisQcijgDGRx46fYT159R1XAd0rvUv6U3QAVkgZFJlu/tRt2D+VlevhEotexW+XA2sQEkAGYtcE4podQQtVpMsGTc24NQh1eaSIt8GuiXsDRhenqm6GiV1AtXgejfrYjvEntg8ImuMEpZEi8HLAqdFbBLlA0iTIc8zx8ZysXf248/oqYGIeeB4PYkJzqDuM8ID6uVuDNClJ4WNqEo2tjOAcIgRU6IOgFo8kOChp6jQOIbkNJ3Jgb66oKTLPYQF7gsW5oEJbTk5UX1N6kUeWFpq4gb4UroCx/M89NaWFGVqRtRNTkrLfH8T3KI2W1pvJ2sqCepwPGe13hupS9oc47d8V/A5cMRlNxHpRuy7aWWFKldvtACNuiEGYBb1xD+IXucufyzXmAHzXQJXMDKD7chk1aCs59nCiVn515Mq7RYT6BdhRCoJMlRN/yDYN1DyaUYYlbEWZaScYRkbXI20kfcuKar4KUV0MeqMhpI8Zg/SapSDg5Mqb+JUApmn5Wv7sqZ7B3WFyaVvouqIwF/N+JcA4idU3w+o9rj6V72bzjRrbCp2ZGhIR328IrDtQIb9i4b/FHIWXTT7Hw9HoKRPuA4uWNYYgQ382N6Rcww0rBKqe6vU4MZB7YIeIT8QLkJPuD1lM9IfOZUh+PQFjy67mjz7giD1Fr1NzCaypmevcb05NlzoRe7gD3tAYP5KtInIAGn3rBmGpt5CaiXYYf5d7g1VoAmaUQyKwsF0mEEcwk9MViIrqnSBLkD4Nwycr+E1xxoY4+VPjuwmeVjWAMSlX1kjcQnpJO0CpQJKRNjPhqkJwmeHB6rdU+0+yw+nRifqOOwsKbP/g=");
            child.Add("associated_data", "pay");
            child.Add("nonce", "uaJahNDr4QOe");

            data.SetValue("resource", child);

            string json = data.ToJsonByNewton();
            string strdata = HttpService.Post(json, "http://127.0.0.1:3877/bus/PayNotify", false, 6);
            //string strdata = HttpService.Post(data.ToJsonByNewton(), "https://test6.ql-soft.com/bus/refundnotify", false, 6);
            return strdata;
        }
    }
}