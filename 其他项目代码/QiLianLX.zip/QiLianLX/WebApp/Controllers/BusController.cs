﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Utils;
using WebApp.WxPayApiV3.lib;

namespace WebApp.Controllers
{
    public class BusController : BaseController
    {
        // GET: Business
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult getTradeList()
        {
            string StrOpenid = GetRequestString("openid", Request);
            //string StrBrid = GetRequestString("brid", Request);
            //string StrYydh = GetRequestString("yydh", Request);
            string StrDingDanHao = GetRequestString("ddh", Request);
            //string StrYuYueZhuangTai = GetRequestString("yyzt", Request);

            IBLL.IBusTradeService bts = new BLL.BusTradeService();
            var TradeList = bts.LoadEntities(t => t.openid == StrOpenid);

            //string strData = SupportTools.HisDataHelper.ExecHisOption(StrOpenid, "1009", "", $"{StrBrid}|{(string.IsNullOrEmpty(StrYydh) ? "-1" : StrYydh)}|{(string.IsNullOrEmpty(StrDingDanHao) ? "-1" : StrDingDanHao)}|{(string.IsNullOrEmpty(StrYuYueZhuangTai) ? "全部" : StrYuYueZhuangTai)}");
            List<Model.BusTrade> list = new List<Model.BusTrade>();
            foreach (var item in TradeList)
            {
                list.Add(item);
            }
            Utils.ResultStruct rs = new Utils.ResultStruct();
            //if (rs.Code == "0")
            //{
            //    try
            //    {
            //        JArray dd = (JArray)Newtonsoft.Json.JsonConvert.DeserializeObject(rs.Data.ToString());
            //        IBLL.IHisYuYueGuaHaoService iyy = new BLL.HisYuYueGuaHaoService();
            //        foreach (JObject item in dd)
            //        {
            //            string dingDanHao = item.GetValue("订单号").ToString();
            //            var localDd = iyy.LoadEntities(h => h.ddh == dingDanHao).FirstOrDefault();
            //            string yingFuJinE = "0";
            //            if (localDd != null)
            //            {
            //                yingFuJinE = localDd.yfje.ToString();
            //                item.Add("应付金额", yingFuJinE);//foreach (JObject item in dd)
            //                if (string.IsNullOrEmpty(item.GetValue("过期时间").ToString()))
            //                {
            //                    item.Remove("过期时间");
            //                    item.Add("过期时间", localDd.gqsj);
            //                }
            //                item.Add("平台状态", localDd.status);
            //                item.Add("备注", localDd.bz);
            //            }
            //            //hisGuaHao.brid = dd[0]["病人ID"].ToString();
            //            //hisGuaHao.ddh = dd[0]["订单号"].ToString();
            //            //hisGuaHao.yfje = (decimal?)dd[0]["应付金额"];
            //            //hisGuaHao.gqsj = (DateTime)dd[0]["过期时间"];
            //            //hisGuaHao.bz = dd[0]["备注"].ToString();

            //            //hisGuaHao = iyy.AddEntity(hisGuaHao);
            //        }
            //        rs.Data = dd.ToString();
            //    }
            //    catch (Exception e) { }
            //}
            rs.Code = "0";
            rs.Data = list;
            return Json(rs, JsonRequestBehavior.AllowGet);
        }


        public ActionResult QueryOrder()
        {
            ResultStruct rs = new ResultStruct();
            rs.Time = DateTime.Now;
            string transaction_id = GetRequestString("transaction_id");
            string out_trade_no = GetRequestString("out_trade_no");

            if (string.IsNullOrEmpty(transaction_id) && string.IsNullOrEmpty(out_trade_no))
            {
                rs.Info = "微信订单号和商户订单号至少填写一个,微信订单号优先！";
                rs.Code = "-1";

            }
            else
            {
                try
                {
                    IBLL.IBusTradeService bts = new BLL.BusTradeService();

                    BusTrade busTrade = bts.LoadEntity(t => t.his_trade_no == out_trade_no);
                    rs.Code = "0";

                    if (busTrade.status == Model.Enum.BusEnum.OrderStatus.待支付.ToString())
                    {
                        //string result = WxPayApiV3.business.OrderQuery.Run(transaction_id, out_trade_no);
                        //WxPayData res = new WxPayData();
                        //res.FromJson(result);

                        //if (res.IsSet("transaction_id"))
                        //{
                        //    busTrade.pay_transaction_no = res.GetValue("transaction_id").ToString();
                        //    busTrade.pay_trade_no = res.GetValue("out_trade_no").ToString();
                        //    busTrade.status = Model.Enum.BusEnum.OrderStatus.已支付.ToString();
                        //    bts.UpdateEntity(busTrade);
                        //}
                        rs.Data = busTrade;// WxPayApiV3.business.OrderQuery.Run(transaction_id, out_trade_no);
                    }
                    else
                    {
                        rs.Data = busTrade;
                    }
                }
                catch (Exception e)
                { }
            }
            return Json(rs, JsonRequestBehavior.AllowGet);
        }
        public ActionResult TradeRefund()
        {
            IBLL.IBusRefundService busService = new BLL.BusRefundService();
            IBLL.IBusTradeService service = new BLL.BusTradeService();
            string refund_id = "";//微信退款单号
            Utils.ResultStruct rs = new Utils.ResultStruct();
            WxPayData result = new WxPayData();

            string ddh = GetRequestString("ddh");

            Model.BusTrade trade = service.LoadEntity(t => t.id_no == ddh);
            Model.BusRefund busRefund = busService.LoadEntity(r => r.trade_no == ddh);//暂时按单次全额退款处理

            if (busRefund == null)
            {
                busRefund = new Model.BusRefund();
                busRefund.trade_no = ddh;
                busRefund.refund_no = WxPayApiV3.lib.WxPayApiV3.GenerateOutTradeNo();
                busRefund.create_time = DateTime.Now;
                busRefund.status = "待退款";
                busRefund = busService.AddEntity(busRefund);
            }

            refund_id = busRefund.refund_no;

            #region 微信支付端退款操作
            if (busRefund.status == "待退款")
            {
                result = WxPayApiV3.business.Refund.Run("", trade.id_no, ((int)(trade.his_receivable * 100)).ToString(), ((int)(trade.his_receivable * 100)).ToString(), busRefund.refund_no);

                if (!result.IsSet("refund_id") || result.GetValue("refund_id").ToString() == "")//!result.IsSet("appid") ||
                {
                    Log.Error(this.GetType().ToString(), "UnifiedOrder response error!");
                    //throw new WxPayException("UnifiedOrder response error!" + result.ToJsonByNewton());
                    rs.Code = "-1";
                    rs.Info = "微信支付退费失败" + result.ToJsonByNewton();
                    return Json(rs, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    //refund_id = result.GetValue("refund_id").ToString();
                    busRefund.status = "已退款";
                    busService.UpdateEntity(busRefund);
                }
            }
            #endregion

            #region HIS端取消操作
            //string StrOpenid = GetRequestString("openid", Request);
            //string StrBrid = GetRequestString("brid", Request);
            //string StrYydh = GetRequestString("yydh", Request);
            //string StrDdh = GetRequestString("ddh", Request);
            //string StrPttkh = GetRequestString("pttkh", Request);//平台退款号
            //string StrPttksj = GetRequestString("pttksj", Request);

            rs = HIS.InterfaceHIS.TradeRefund(trade, busRefund);
            if (rs.Code != "0")
                return Json(rs, JsonRequestBehavior.AllowGet);

            #endregion

            #region 平台数据处理
            busRefund.status = "交易撤销";
            busService.UpdateEntity(busRefund);
            trade.status = Model.Enum.BusEnum.OrderStatus.已退款.ToString();
            service.UpdateEntity(trade);
            #endregion


            //try
            //{
            //    //IBLL.IHisYuYueGuaHaoService service = new BLL.HisYuYueGuaHaoService();
            //    Model.HisYuYueGuaHao yyxq = service.LoadEntity(y => y.ddh == ddh);
            //    if (!string.IsNullOrEmpty(yyxq.status) && yyxq.status == "预约")
            //    {
            //        yyxq.status = "申请取消";
            //        if (service.UpdateEntity(yyxq))
            //        {
            //            rs.Code = "0";
            //            rs.Info = "申请成功";
            //        }
            //        else
            //        {
            //            rs.Code = "-1";
            //            rs.Info = "申请失败";
            //        }
            //    }
            //    else
            //    {
            //        rs.Code = "-1";
            //        rs.Info = "请确认当前预约状态是否可取消";
            //    }

            //}
            //catch (Exception e)
            //{
            //    rs.Code = "-1";
            //    rs.Info = e.Message;
            //}

            rs.Code = "0";
            rs.Info = "退费成功";
            rs.Data = result;
            return Json(rs, JsonRequestBehavior.AllowGet);
            //}
        }

        public ActionResult PayNotify()
        {
            Dictionary<string, string> res = new Dictionary<string, string>();
            try
            {
                Newtonsoft.Json.Linq.JObject jobj = new Newtonsoft.Json.Linq.JObject();
                if (Request.Headers.Get("content-type") == "application/json")
                {
                    string content = GetRequestString("application/json");
                    Log.Debug(this.GetType().ToString(), "content:" + content);
                    //jobj = (Newtonsoft.Json.Linq.JObject)Newtonsoft.Json.JsonConvert.DeserializeObject(content);
                    WxPayData message = new WxPayData();
                    message.FromJson(content);

                    string resource = message.GetValue("resource").ToString();
                    WxPayData msg = new WxPayData();
                    msg.FromJson(resource);

                    string key = "wx4d2cb14f8cf85cabwx4d2cb14f8cf8";
                    string nonce = msg.GetValue("nonce").ToString();
                    string cipherData = msg.GetValue("ciphertext").ToString();
                    string associatedData = msg.GetValue("associated_data").ToString();
                    string decryptResource = AesGcm.AesGcmDecryptByBouncyCastle(key, nonce, cipherData, associatedData);

                    WxPayData decryptResourceObj = new WxPayData();
                    decryptResourceObj.FromJson(decryptResource);

                    string transaction_id = decryptResourceObj.GetValue("transaction_id").ToString();
                    string amount = decryptResourceObj.GetValue("amount").ToString();
                    string mchid = decryptResourceObj.GetValue("mchid").ToString();
                    string trade_state = decryptResourceObj.GetValue("trade_state").ToString();
                    string bank_type = decryptResourceObj.GetValue("bank_type").ToString();
                    string promotion_detail = "";
                    if (decryptResourceObj.IsSet("promotion_detail"))
                        promotion_detail = decryptResourceObj.GetValue("promotion_detail").ToString();

                    string success_time = decryptResourceObj.GetValue("success_time").ToString();
                    string payer = decryptResourceObj.GetValue("payer").ToString();
                    string out_trade_no = decryptResourceObj.GetValue("out_trade_no").ToString();
                    string appid = decryptResourceObj.GetValue("appid").ToString();
                    string trade_state_desc = decryptResourceObj.GetValue("trade_state_desc").ToString();
                    string trade_type = decryptResourceObj.GetValue("trade_type").ToString();
                    string attach = decryptResourceObj.GetValue("attach").ToString();
                    //string scene_info = decryptResourceObj.GetValue("scene_info").ToString();

                    try
                    {
                        IBLL.IBusTradeService bts = new BLL.BusTradeService();

                        BusTrade busTrade = bts.LoadEntity(t => t.his_trade_no == out_trade_no);
                        //rs.Code = "0";

                        if (busTrade != null && busTrade.status == Model.Enum.BusEnum.OrderStatus.待支付.ToString())
                        {
                            //string result = WxPayApiV3.business.OrderQuery.Run(transaction_id, out_trade_no);
                            //WxPayData res = new WxPayData();
                            //res.FromJson(result);

                            if (!string.IsNullOrEmpty(transaction_id))
                            {
                                busTrade.pay_transaction_no = transaction_id;// res.GetValue("transaction_id").ToString();
                                busTrade.pay_trade_no = out_trade_no;// res.GetValue("out_trade_no").ToString();
                                busTrade.status = Model.Enum.BusEnum.OrderStatus.已支付.ToString();
                                if (bts.UpdateEntity(busTrade))
                                {
                                    res.Add("code", "SUCCESS");
                                    res.Add("message", "");
                                }
                            }
                        }
                    }
                    catch (Exception e)
                    { }
                }

                //Log.Debug(this.GetType().ToString(), "Notify:");
                //string id = jobj.GetValue("id").ToString();
                //Log.Debug(this.GetType().ToString(), "id:" + id);
                //string create_time = jobj.GetValue("create_time").ToString();
                //Log.Debug(this.GetType().ToString(), "create_time:" + create_time);
                //string event_type = jobj.GetValue("event_type").ToString();
                //Log.Debug(this.GetType().ToString(), "event_type:" + event_type);
                //string resource_type = jobj.GetValue("resource_type").ToString();
                //Log.Debug(this.GetType().ToString(), "resource_type:" + resource_type);
                //string resource = jobj.GetValue("resource").ToString();
                //Log.Debug(this.GetType().ToString(), "resource:" + resource);
                //string summary = jobj.GetValue("summary").ToString();
            }
            catch (Exception e)
            {
                Log.Debug(this.GetType().ToString(), "exception" + e.Message + e.StackTrace);
            }
            if (!res.Keys.Contains("code"))
                res.Add("code", "failed");
            res.Add("message", "");
            return Json(res, JsonRequestBehavior.AllowGet);
        }
        public ActionResult RefundNotify(string param)
        {
            Dictionary<string, string> res = new Dictionary<string, string>();
            try
            {
                WxPayData messag = new WxPayData();
                Newtonsoft.Json.Linq.JObject jobj = new Newtonsoft.Json.Linq.JObject();
                if (Request.Headers.Get("content-type") == "application/json")
                {
                    string content = GetRequestString("application/json");
                    //Log.Debug(this.GetType().ToString(), "content:" + content);
                    messag.FromJson(content);
                    jobj = (Newtonsoft.Json.Linq.JObject)Newtonsoft.Json.JsonConvert.DeserializeObject(content);
                    //WxPayData msg  = 
                    string resource = messag.GetValue("resource").ToString();
                    WxPayData msg = new WxPayData();
                    msg.FromJson(resource);

                    string key = "wx4d2cb14f8cf85cabwx4d2cb14f8cf8";
                    string nonce = msg.GetValue("nonce").ToString();
                    string cipherData = msg.GetValue("ciphertext").ToString();
                    string associatedData = msg.GetValue("associated_data").ToString();
                    string decryptResource = AesGcm.AesGcmDecryptByBouncyCastle(key, nonce, cipherData, associatedData);

                    string encryptTest = AesGcm.AesGcmEncryptByBouncyCastle(key, nonce, decryptResource, associatedData);

                    WxPayData decryptResourceObj = new WxPayData();
                    decryptResourceObj.FromJson(decryptResource);
                    string mchid = decryptResourceObj.GetValue("mchid").ToString();
                    string out_trade_no = decryptResourceObj.GetValue("out_trade_no").ToString();
                    string transaction_id = decryptResourceObj.GetValue("transaction_id").ToString();
                    string out_refund_no = decryptResourceObj.GetValue("out_refund_no").ToString();
                    string refund_id = decryptResourceObj.GetValue("refund_id").ToString();
                    string refund_status = decryptResourceObj.GetValue("refund_status").ToString();
                    string success_time = decryptResourceObj.GetValue("success_time").ToString();
                    string amount = decryptResourceObj.GetValue("amount").ToString();
                    string user_received_account = decryptResourceObj.GetValue("user_received_account").ToString();

                    WxPayData amountObj = new WxPayData();
                    amountObj.FromJson(amount);

                }
                //Log.Debug(this.GetType().ToString(), "Notify:");
                //string id = GetRequestString("id");
                //Log.Debug(this.GetType().ToString(), "id:" + id);
                //string create_time = GetRequestString("create_time");
                //Log.Debug(this.GetType().ToString(), "create_time:" + create_time);
                //string event_type = GetRequestString("event_type");
                //Log.Debug(this.GetType().ToString(), "event_type:" + event_type);
                //string resource_type = GetRequestString("resource_type");
                //Log.Debug(this.GetType().ToString(), "resource_type:" + resource_type);
                //string resource = GetRequestString("resource");
                //Log.Debug(this.GetType().ToString(), "resource:" + resource);
                //string summary = GetRequestString("summary");
            }
            catch (Exception e)
            {
                Log.Debug(this.GetType().ToString(), "exception" + e.Message + e.StackTrace);
            }
            res.Add("code", "SUCCESS");
            res.Add("message", "");
            return Json(res, JsonRequestBehavior.AllowGet);
        }
    }

    public class AesGcm
    {
        /// <summary>
        /// 使用BouncyCastle进行AEAD_AES_256_GCM 解密
        /// </summary>
        /// <param name="key">key:32位字符</param>
        /// <param name="nonce">随机串12位</param>
        /// <param name="cipherData">密文(Base64字符)</param>
        /// <param name="associatedData">附加数据可能null</param>
        /// <returns></returns>
        public static string AesGcmDecryptByBouncyCastle(string key, string nonce, string cipherData, string associatedData)
        {
            var associatedBytes = associatedData == null ? null : System.Text.Encoding.UTF8.GetBytes(associatedData);

            var gcmBlockCipher = new Org.BouncyCastle.Crypto.Modes.GcmBlockCipher(new Org.BouncyCastle.Crypto.Engines.AesEngine());
            var parameters = new Org.BouncyCastle.Crypto.Parameters.AeadParameters(
                new Org.BouncyCastle.Crypto.Parameters.KeyParameter(System.Text.Encoding.UTF8.GetBytes(key)),
                128,  //128 = 16 * 8 => (tag size * 8)
                System.Text.Encoding.UTF8.GetBytes(nonce),
                associatedBytes);
            gcmBlockCipher.Init(false, parameters);

            var data = Convert.FromBase64String(cipherData);
            var plaintext = new byte[gcmBlockCipher.GetOutputSize(data.Length)];

            var length = gcmBlockCipher.ProcessBytes(data, 0, data.Length, plaintext, 0);
            gcmBlockCipher.DoFinal(plaintext, length);
            return System.Text.Encoding.UTF8.GetString(plaintext);
        }
        /// <summary>
        /// 使用BouncyCastle进行AEAD_AES_256_GCM 加密
        /// </summary>
        /// <param name="key">key32位字符</param>
        /// <param name="nonce">随机串12位</param>
        /// <param name="plainData">明文</param>
        /// <param name="associatedData">附加数据可能null</param>
        /// <returns></returns>
        public static string AesGcmEncryptByBouncyCastle(string key, string nonce, string plainData, string associatedData)
        {
            var associatedBytes = associatedData == null ? null : System.Text.Encoding.UTF8.GetBytes(associatedData);

            var gcmBlockCipher = new Org.BouncyCastle.Crypto.Modes.GcmBlockCipher(new Org.BouncyCastle.Crypto.Engines.AesEngine());
            var parameters = new Org.BouncyCastle.Crypto.Parameters.AeadParameters(
                new Org.BouncyCastle.Crypto.Parameters.KeyParameter(System.Text.Encoding.UTF8.GetBytes(key)),
                128, //128 = 16 * 8 => (tag size * 8)
                System.Text.Encoding.UTF8.GetBytes(nonce),
                associatedBytes);
            gcmBlockCipher.Init(true, parameters);

            var data = System.Text.Encoding.UTF8.GetBytes(plainData);
            var cipherData = new byte[gcmBlockCipher.GetOutputSize(data.Length)];

            var length = gcmBlockCipher.ProcessBytes(data, 0, data.Length, cipherData, 0);
            gcmBlockCipher.DoFinal(cipherData, length);
            return Convert.ToBase64String(cipherData);
        }
    }
}