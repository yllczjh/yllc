﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp.Controllers
{
    public class BaseController : Controller
    {
        protected string Msg = "";
        public static string accessToken { get { return Utils.WechatHelper.AccessToken; } }
        public static string pk = "";
        public const int defaultPageSize = 20;

        /// <summary>
        /// 执行控制器方法之前先执行该方法
        /// <para>获取自定义的sessionId值，然后判断登陆有效性</para>
        /// </summary>
        /// <param name="filterContext"></param>
        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (Request.Cookies["session"] == null)
            {
                Response.Cookies["session"].Value = Guid.NewGuid().ToString();
            }
            object obj = Session[Request.Cookies["session"].Value];
            //if(obj==null)
            //    Response.Cookies["sessionId"].Value = Guid.NewGuid().ToString();


            base.OnActionExecuting(filterContext);
        }
        public BaseController()
        {
            pk = Guid.NewGuid().ToString();
            //WxPayApiV3.lib.Log.Debug("BaseController", pk + ",accessToken:" + (accessToken != null ? accessToken.Token : ""));
            //WxPayApiV3.lib.Log.Debug("BaseController", pk + ",accessToken:" + accessToken);
        }
        // GET: Base
        //public ActionResult Index()
        //{
        //    return View();
        //}

        public string GetRequestString(string name)
        {
            return GetRequestString(name, Request);
        }

        public string GetRequestString(string name, HttpRequestBase request)
        {
            if (request == null)
                request = this.Request;
            string content_Type = request.Headers.Get("content-type");
            if (content_Type == "application/x-www-form-urlencoded")
            {
                string param = request.Params[name];

                return string.IsNullOrEmpty(param) ? request.Form[name] : param;
            }
            else if (content_Type == "application/json")
            {
                System.IO.Stream sream = request.InputStream;
                sream.Position = 0;
                System.IO.StreamReader sr = new StreamReader(sream);
                //byte[] buffer = new byte[sream.Length];
                //int sha = sream.Read(buffer, 0, (int)sream.Length);
                string search = sr.ReadToEnd();
                sr.Close();
                var jSetting = new Newtonsoft.Json.JsonSerializerSettings
                {
                    NullValueHandling = Newtonsoft.Json.NullValueHandling.Ignore
                };
                object obj = Newtonsoft.Json.JsonConvert.DeserializeObject(search, jSetting);
                return obj.ToString();
            }
            else { return request.Params[name]; }
        }
    }
}