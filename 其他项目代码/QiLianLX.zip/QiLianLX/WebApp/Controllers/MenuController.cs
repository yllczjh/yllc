﻿using BLL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApp.Models;

namespace WebApp.Controllers
{
    public class MenuController : BaseController
    {
        // GET: Menu
        public ActionResult Index()
        {
            MenuService ms = new MenuService();
            var q = ms.LoadEntitis(e => 1 == 1);
            //foreach (var a in q)
            //{ }
            var list = GetMenuTree(q.ToList(), null);
            return Json(list, JsonRequestBehavior.AllowGet);
        }

        private List<MenuItem> GetMenuTree(List<Menu> list, string parentId)
        {
            List<MenuItem> tree = new List<MenuItem>();
            List<Menu> ChildList = list.Where(m => m.parentId == parentId).ToList();
            foreach (var item in ChildList)
            {
                MenuItem subTree = new MenuItem();
                subTree.menu = item;
                subTree.child = GetMenuTree(list, item.id);
                tree.Add(subTree);
            }
            return tree;
        }
        //public ActionResult GetReportParamList()
        //{
        //    string mId = Request["m_id"];
        //    S_reportParamService srs = new S_reportParamService();
        //    List<S_reportParam> list = srs.LoadEntities(e => e.m_id == mId).ToList();
        //    list.OrderBy(e => e.sort);
        //    return Json(list, JsonRequestBehavior.AllowGet);
        //}
    }
}