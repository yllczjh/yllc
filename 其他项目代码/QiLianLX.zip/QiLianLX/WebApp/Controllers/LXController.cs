﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Model;

namespace WebApp.Controllers
{
    public class LXController : BaseController
    {
        IBLL.Ijc_yhService yhService = new BLL.jc_yhService();
        IBLL.Ijc_qyService qyService = new BLL.jc_qyService();
        IBLL.Ijc_yh_qyService yhqyService = new BLL.jc_yh_qyService();
        IBLL.Ijc_qy_cpService qycpService = new BLL.jc_qy_cpService();
        IBLL.Ijc_yh_cpService yhcpService = new BLL.jc_yh_cpService();
        IBLL.Iyw_mxService ywmxService = new BLL.yw_mxService();
        IBLL.Iyw_kcService ywkcService = new BLL.yw_kcService();
        // GET: LX
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult SalesmanQy()
        {

            //string strPageIndex = GetRequestString("pageIndex");
            //int pageIndex = int.Parse(strPageIndex);
            //int pageSize = defaultPageSize;
            string strSalesman = GetRequestString("salesman");
            int salesman = int.Parse(string.IsNullOrEmpty(strSalesman) ? "0" : strSalesman);


            IQueryable<jc_yh> yh = yhService.LoadEntities(a => a.禁用 == false);
            IQueryable<jc_yh_qy> yhqy = yhqyService.LoadEntities(a => a.禁用 == false);
            IQueryable<jc_qy> qy = qyService.LoadEntities();

            var array = (from aa in yh

                           where aa.禁用 == false && aa.rowid==salesman
                           select new { aa.上级id }).ToArray();
            
            int? []yhArray = new int?[array.Length];

            for (int i=0;i< array.Length; i++)
            {
                yhArray[i] = array[i].上级id;
            }

            IQueryable temp = (from a in yh
                               join b in yhqy on new { 用户id = a.rowid } equals new { b.用户id }
                               join c in qy on new { b.企业id } equals new { 企业id = c.rowid }
                               //new int?[] {1,2 }
                               where (a.rowid == salesman || 
                               (yhArray
                               //from aa in yh
                                
                               // where aa.禁用 == false
                               // select new { 用户id = (int?)aa.rowid }
                               ).Contains(a.rowid)) && a.禁用 == false
                               && b.禁用 == false && b.审核 == true && b.有效期至 > DateTime.Now

                               select new
                               {
                                   用户编码 = a.rowid,
                                   id = b.企业id,
                                   name = c.企业名称
                               }).OrderBy(o => new { o.name });

            Utils.ResultStruct rs = new Utils.ResultStruct();
            rs.Code = "0";
            rs.Data = temp;
            return Json(rs, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 业务员产品目录
        /// </summary>
        /// <returns></returns>
        public ActionResult supplierDrug()
        {
            string strSalesman = GetRequestString("salesman");
            int salesman = int.Parse(string.IsNullOrEmpty(strSalesman) ? "0" : strSalesman);
            string strPageIndex = GetRequestString("pageIndex");
            int pageIndex = int.Parse(strPageIndex);
            int pageSize = defaultPageSize;
            string strCurrentQy = GetRequestString("currentQy");
            int currentQy = string.IsNullOrEmpty(strCurrentQy) ? 0 : int.Parse(strCurrentQy);
            //int totalCount = 0;
            //int count = 0;
            //var yhcp = yhcpService.LoadEntities<int>(1,10,out count, u => u.用户企业id != 0, a=>a.产品id,true);
            IQueryable<jc_yh> yh = yhService.LoadEntities(y => y.rowid != 0);
            IQueryable<jc_yh_qy> yhqy = yhqyService.LoadEntities(yq => yq.rowid != 0);
            var yhcp = yhcpService.LoadEntities(u => u.用户企业id != 0);
            var qycp = qycpService.LoadEntities(q => q.企业id == currentQy);

            IQueryable temp = (from a in yh
                               join ab in yhqy on a.rowid equals ab.用户id
                               join abc in yhcp on ab.rowid equals abc.用户企业id
                               join c in qycp on abc.产品id equals c.rowid
                               where (a.rowid == salesman || a.上级id == salesman) && a.禁用 == false && ab.禁用 == false && ab.审核 == true
                               && ab.有效期至 > DateTime.Now && abc.审核 == true && abc.禁用 == false
                               && c.审核 == true && c.禁用 == false
                               orderby a.rowid ascending, c.产品名称
                               select new
                               {
                                   a.姓名,
                                   c.产品名称,
                                   c.产品编号,
                                   c.产地,
                                   c.规格,
                                   c.分类
                               }).OrderBy(p => p.产品名称).Skip((pageIndex - 1) * pageSize).Take(pageSize);


            Utils.ResultStruct res = new Utils.ResultStruct();
            res.Code = "0";
            res.Data = temp;
            return Json(res, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 业务流向
        /// </summary>
        /// <returns></returns>
        public ActionResult BusFlow()
        {
            string strPageIndex = GetRequestString("pageIndex");
            int pageIndex = int.Parse(strPageIndex);
            int pageSize = defaultPageSize;
            string strSalesman = GetRequestString("salesman");
            int salesman = int.Parse(string.IsNullOrEmpty(strSalesman) ? "0" : strSalesman);
            string strCurrentQy = GetRequestString("currentQy");
            int currentQy = string.IsNullOrEmpty(strCurrentQy) ? 0 : int.Parse(strCurrentQy);
            string kssj = GetRequestString("kssj");
            string jssj = GetRequestString("jssj");

            DateTime datKssj = string.IsNullOrEmpty(kssj) ? DateTime.Today : DateTime.Parse(kssj);
            DateTime datJssj = string.IsNullOrEmpty(jssj) ? DateTime.Today : DateTime.Parse(jssj + " 23:59:59");

            IQueryable<jc_yh> yh = yhService.LoadEntities(a => a.rowid >= 0);
            IQueryable<jc_yh_qy> yhqy = yhqyService.LoadEntities(a => a.rowid == a.rowid);
            IQueryable<jc_qy_cp> qycp = qycpService.LoadEntities(a => true);
            IQueryable<jc_yh_cp> yhqycp = yhcpService.LoadEntities();
            IQueryable<yw_mx> mx = ywmxService.LoadEntities(a => a.rowid >= 0);

            IQueryable temp = (from a in yh
                               join b in yhqy on new { 用户id = a.rowid } equals new { b.用户id }
                               //join c in qycp on new {b.企业id} equals new { c.企业id}
                               join d in yhqycp on new { 用户企业id = b.rowid } equals new { d.用户企业id }
                               join e in mx on new { 产品id = d.rowid, b.企业id } equals new { e.产品id, e.企业id }
                               where (a.rowid == salesman || a.上级id == salesman) && a.禁用 == false
                               && b.禁用 == false && b.审核 == true && b.有效期至 > DateTime.Now
                               && d.审核 == true && d.禁用 == false && e.单据日期 > datKssj && e.单据日期 < datJssj
                               && b.企业id == currentQy
                               select new
                               {
                                   用户编码 = a.rowid,
                                   b.企业id,
                                   d.产品id,
                                   e.单价,
                                   e.单据类型,
                                   e.单据日期,
                                   e.单据备注,
                                   e.单据编号,
                                   e.客户信息,
                                   e.批号,
                                   e.效期,
                                   e.数量,
                                   e.明细备注,
                                   e.明细标识,
                                   e.生产日期,
                                   e.金额
                               }).OrderBy(o => new { o.产品id, o.企业id }).Skip((pageIndex - 1) * pageSize).Take(pageSize);

            Utils.ResultStruct rs = new Utils.ResultStruct();
            rs.Code = "0";
            rs.Data = temp;
            return Json(rs, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 库存
        /// </summary>
        /// <returns></returns>
        public ActionResult Stock()
        {
            string strPageIndex = GetRequestString("pageIndex");
            int pageIndex = int.Parse(strPageIndex);
            int pageSize = defaultPageSize;
            string strSalesman = GetRequestString("salesman");
            string strCurrentQy = GetRequestString("currentQy");
            int salesman = int.Parse(string.IsNullOrEmpty(strSalesman) ? "0" : strSalesman);
            int currentQy = int.Parse(string.IsNullOrEmpty(strCurrentQy) ? "0" : strCurrentQy);


            IQueryable<jc_yh> yh = yhService.LoadEntities(a => a.禁用 == false);
            IQueryable<jc_yh_qy> yhqy = yhqyService.LoadEntities();
            IQueryable<jc_qy_cp> qycp = qycpService.LoadEntities();
            IQueryable<jc_yh_cp> yhqycp = yhcpService.LoadEntities();
            IQueryable<yw_kc> kc = ywkcService.LoadEntities();

            IQueryable temp = (from a in yh
                               join b in yhqy on new { 用户id = a.rowid } equals new { b.用户id }
                               //join c in qycp on new {b.企业id} equals new { c.企业id}
                               join d in yhqycp on new { 用户企业id = b.rowid } equals new { d.用户企业id }
                               join e in kc on new { 产品id = (int?)d.产品id, 企业id = (int?)b.企业id } equals new { e.产品id, e.企业id }
                               where (a.rowid == salesman || a.上级id == salesman) && b.企业id == currentQy
                               && a.禁用 == false && b.审核 == true && b.禁用 == false && b.有效期至 > DateTime.Now
                               && d.审核 == true && d.禁用 == false

                               select new
                               {
                                   用户编码 = a.rowid,
                                   b.企业id,
                                   d.产品id,
                                   e.批号,
                                   e.效期,
                                   e.数量,
                                   e.明细备注,
                                   e.明细标识,
                                   e.生产日期,
                                   e.进价,
                                   e.金额
                               }).OrderBy(o => new { o.产品id, o.企业id }).Skip((pageIndex - 1) * pageSize).Take(pageSize);

            Utils.ResultStruct rs = new Utils.ResultStruct();
            rs.Code = "0";
            rs.Data = temp;
            return Json(rs, JsonRequestBehavior.AllowGet);
        }
    }
}