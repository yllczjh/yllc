﻿using LitJson;
using Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;
using Utils;
using WebApp.WxPayApi;

namespace WebApp.Controllers
{
    public class WeixinController : BaseController
    {

        //公众号配置Token，用于获取交互的Token
        public static string BaseToken = Utils.WechatHelper.BaseToken;
        public static WxWebGrant wxWebGrant;

        #region 1.微信公众号 接入
        /// <summary>
        /// GET请求， 微信公众号开发者服务器配置时，验证服务器有效性
        /// </summary>
        public void Index()
        {
            InterfaceTest();
        }

        /// <summary>
        /// 成为开发者url测试，返回echoStr
        /// </summary>
        public void InterfaceTest()
        {
            //string token = "填写的token";
            string token = BaseToken;
            if (string.IsNullOrEmpty(token))
            {
                return;
            }

            string echoString = HttpContext.Request.QueryString["echoStr"];
            string signature = HttpContext.Request.QueryString["signature"];
            string timestamp = HttpContext.Request.QueryString["timestamp"];
            string nonce = HttpContext.Request.QueryString["nonce"];
            
            if (checkSignature(signature, timestamp, nonce))
            {
                HttpContext.Response.Write(echoString);
                HttpContext.Response.End();
            }
        }
        /// <summary>
        /// 用于接入微信公众平台开发，验证服务器地址的有效性
        /// </summary>
        /// <param name="signature">微信加密签名，signature结合了开发者填写的token参数和请求中的timestamp参数、nonce参数。</param>
        /// <param name="timestamp">时间戳</param>
        /// <param name="nonce">随机数</param>
        /// <returns></returns>
        private bool checkSignature(string signature, string timestamp, string nonce)
        {
            string token = BaseToken;
            string[] arr = new string[] { token, timestamp, nonce };
            Array.Sort(arr);

            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            foreach (string str in arr)
            {
                sb.Append(str);
            }

            try
            {
                byte[] bytes = System.Text.Encoding.UTF8.GetBytes(sb.ToString());
                byte[] sha1 = System.Security.Cryptography.SHA1.Create().ComputeHash(bytes);
                sb = new System.Text.StringBuilder();
                foreach (byte b in sha1)
                {
                    sb.Append(b.ToString("X2"));
                }
                if (sb.ToString().ToLower().Equals(signature))
                    return true;
            }
            catch (Exception e)
            { }
            return false;
        }
        #endregion

        #region 2.微信公众号自定义菜单业务处理 WechatMenu
        public ActionResult CreateWechatMenu()
        {
            //////全局用需定义全局变量
            // 第三方用户唯一凭证  
            //      String appId = "你的appId";  
            string appId = Utils.WechatHelper.appId;
            // 第三方用户唯一凭证密钥  
            string appSecret = Utils.WechatHelper.appSecret;

            FileStream fs1 = new FileStream(Server.MapPath("..") + "\\WechatMenu.txt", FileMode.Open);
            StreamReader sr = new StreamReader(fs1, Encoding.GetEncoding("GBK"));
            string menu = sr.ReadToEnd();
            sr.Close();
            fs1.Close();
            //if(accessToken==null||accessToken.AcquireTime.AddSeconds(accessToken.ExpiresIn-300)>DateTime.Now)`    
            //Utils.AccessToken at = Utils.WechatHelper.getAccessToken(appId, appSecret);
            menu = menu.Replace("APPID", Utils.WechatHelper.appId);
            string content = GetPage("https://api.weixin.qq.com/cgi-bin/menu/create?access_token=" + accessToken, menu);
            return Json(content, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetWechatMenu()
        {
            //////全局用需定义全局变量
            // 第三方用户唯一凭证  
            //      String appId = "你的appId";  
            string appId = Utils.WechatHelper.appId;
            // 第三方用户唯一凭证密钥  
            string appSecret = Utils.WechatHelper.appSecret;

            //FileStream fs1 = new FileStream(Server.MapPath("..") + "\\WechatMenu.txt", FileMode.Open);
            //StreamReader sr = new StreamReader(fs1, Encoding.GetEncoding("GBK"));
            //string menu = sr.ReadToEnd();
            //sr.Close();
            //fs1.Close();
            //if (accessToken == null || accessToken.AcquireTime.AddSeconds(accessToken.ExpiresIn <= 0 ? 7200 : accessToken.ExpiresIn) < DateTime.Now)
                //accessToken = Utils.WechatHelper.getAccessToken(appId, appSecret);
            Newtonsoft.Json.Linq.JObject serverMenu = Utils.WechatHelper.httpsRequest(WechatHelper.WxApiDomain + "cgi-bin/get_current_selfmenu_info?access_token=" + accessToken, "GET", "");
            //string content = GetPage("https://api.weixin.qq.com/cgi-bin/get_current_selfmenu_info?access_token=" + at.Token);

            System.IO.File.WriteAllText(Server.MapPath("..") + "\\WechatServerMenu.txt", serverMenu.ToString());

            return Json(serverMenu.ToString(), JsonRequestBehavior.AllowGet);
        }
        public string GetPage(string posturl, string postData)
        {
            Stream outstream = null;
            Stream instream = null;
            StreamReader sr = null;
            HttpWebResponse response = null;
            HttpWebRequest request = null;
            Encoding encoding = Encoding.UTF8;
            byte[] data = encoding.GetBytes(postData);
            // 准备请求...
            try
            {
                // 设置参数
                request = WebRequest.Create(posturl) as HttpWebRequest;
                CookieContainer cookieContainer = new CookieContainer();
                request.CookieContainer = cookieContainer;
                request.AllowAutoRedirect = true;
                request.Method = "POST";
                request.ContentType = "application/x-www-form-urlencoded";
                request.ContentLength = data.Length;
                outstream = request.GetRequestStream();
                outstream.Write(data, 0, data.Length);
                outstream.Close();
                //发送请求并获取相应回应数据
                response = request.GetResponse() as HttpWebResponse;
                //直到request.GetResponse()程序才开始向目标网页发送Post请求
                instream = response.GetResponseStream();
                sr = new StreamReader(instream, encoding);
                //返回结果网页（html）代码
                string content = sr.ReadToEnd();
                string err = string.Empty;
                Response.Write(content);
                return content;
            }
            catch (Exception ex)
            {
                string err = ex.Message;
                return string.Empty;
            }
        }
        #endregion

        public ActionResult GuaHao()
        {
            int iParams = Request.Params.Count;
            ViewBag.Param = iParams;
            string str_code = Request.Params["code"];
            if (string.IsNullOrEmpty(str_code))
                return Json("请通过微信公众号打开此链接", JsonRequestBehavior.AllowGet);

            IBLL.IWx_grantService wx_gs = new BLL.Wx_grantService();
            var ent = wx_gs.LoadEntities(w => w.code == str_code);
            if (ent.Count() != 0)
            {
                return Redirect("http://test6.ql-soft.com/wxgzh/#/?src=bd&openid=" + ent.FirstOrDefault().openid);
                //return View(ent);
            }

            string str_accessToken链接 = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=APPID&secret=SECRET&code=CODE&grant_type=authorization_code";

            str_accessToken链接 = str_accessToken链接.Replace("APPID", Utils.WechatHelper.appId).Replace("SECRET", Utils.WechatHelper.appSecret).Replace("CODE", str_code);

            Newtonsoft.Json.Linq.JObject jObj = Utils.WechatHelper.httpsRequest(str_accessToken链接, "GET", null);
            if (jObj.Property("openid") == null)
            {
                ent = wx_gs.LoadEntities(w => w.code == str_code);
                if (ent.Count() != 0)
                {
                    return Redirect("http://test6.ql-soft.com/wxgzh/#/?src=bd&openid=" + ent.FirstOrDefault().openid + "&code=" + str_code);
                    //return View(ent);
                }
                else
                {
                    ViewBag.back = jObj;
                    return View(jObj);
                }
            }
            string openid = jObj.GetValue("openid").ToString();
            ViewBag.back = openid;

            var old_grant = wx_gs.LoadEntities(w => w.openid == openid).FirstOrDefault();
            if (old_grant != null)
            {
                Model.Wx_grant grant = old_grant;
                grant.access_token = jObj.GetValue("openid").ToString();
                grant.code = str_code;
                grant.expires_in = jObj.GetValue("expires_in").ToString();
                grant.grant_type = "authorization_code";
                //new Model.Wx_grant() { grantid = openid, openid = openid, access_token = jObj.GetValue("openid").ToString(), code = str_code, expires_in = jObj.GetValue("expires_in").ToString(), grant_type = "authorization_code" }
                if (wx_gs.UpdateEntity(grant))
                    //return View(grant);
                    return Redirect("http://test6.ql-soft.com/wxgzh/index/index?src=gengxinde&openid=" + grant.openid + "&code=" + str_code);
                else
                    return Redirect("baidu.com");
            }
            else
            {
                Model.Wx_grant grant = wx_gs.AddEntity(new Model.Wx_grant() { grantid = openid, openid = openid, access_token = jObj.GetValue("openid").ToString(), code = str_code, expires_in = jObj.GetValue("expires_in").ToString(), grant_type = "authorization_code" });
                return View(grant);
            }
        }

        public ActionResult GetEditAddressParameters()
        {
            JsApiPay jsApiPay = new JsApiPay(Request);
            try
            {
                string str_code = Request.Params["code"];
                if (!string.IsNullOrEmpty(str_code))
                {
                    if (wxWebGrant == null || wxWebGrant.code != str_code)
                        wxWebGrant = getLocalWebGrantInfoFromCode(str_code);
                    //调用【网页授权获取用户信息】接口获取用户的openid和access_token
                    if (wxWebGrant == null)
                        wxWebGrant = GetOpenidAndAccessToken();
                    if (wxWebGrant.acquireTime <= DateTime.Now.AddSeconds(-(double)(wxWebGrant.expires_in - 300)))
                    {
                        //TODO:刷新授权  获取新的accessToken
                    }
                }
                else
                {
                }

                jsApiPay.access_token = wxWebGrant.access_token;
                jsApiPay.openid = wxWebGrant.openid;

                //获取收货地址js函数入口参数
                string wxEditAddrParam = jsApiPay.GetEditAddressParameters();

                Dictionary<string, string> dic = new System.Collections.Generic.Dictionary<string, string>();
                dic.Add("wxEditAddrParam", wxEditAddrParam);
                dic.Add("openid", jsApiPay.openid);

                Utils.ResultStruct res = new Utils.ResultStruct();
                res.Code = "0";
                res.Time = DateTime.Now;
                res.Info = Msg;
                res.Data = dic;
                return Json(res, JsonRequestBehavior.AllowGet);
            }
            catch (Exception e)
            {
                Msg = e.Message;

                Utils.ResultStruct res = new Utils.ResultStruct();
                res.Code = "-1";
                res.Time = DateTime.Now;
                res.Info = Msg;
                return Json(res, JsonRequestBehavior.AllowGet);
            }
        }

        //public ActionResult GetWebGrant()
        //{
        //    JsApiPay jsApiPay = new JsApiPay(Request);
        //    Wx_grant grant = null;
        //    try
        //    {
        //        string str_code = Request.Params["code"];
        //        if (!string.IsNullOrEmpty(str_code))
        //            grant = getLocalGrantInfoFromCode(str_code);
        //        if (grant == null)
        //        {
        //            //调用【网页授权获取用户信息】接口获取用户的openid和access_token
        //            GetOpenidAndAccessToken();
        //        }
        //        else
        //        {
        //            jsApiPay.access_token = accessToken.Token;
        //            //jsApiPay.openid = accessToken.
        //        }
        //        //获取收货地址js函数入口参数
        //        string wxEditAddrParam = jsApiPay.GetEditAddressParameters();

        //        Dictionary<string, string> dic = new System.Collections.Generic.Dictionary<string, string>();
        //        dic.Add("wxEditAddrParam", wxEditAddrParam);
        //        dic.Add("openid", jsApiPay.openid);

        //        Utils.ResultStruct res = new Utils.ResultStruct();
        //        res.Code = "0";
        //        res.Time = DateTime.Now;
        //        res.Info = Msg;
        //        res.Data = dic;
        //        return Json(res, JsonRequestBehavior.AllowGet);
        //    }
        //    catch (Exception e)
        //    {
        //        Msg = e.Message;

        //        Utils.ResultStruct res = new Utils.ResultStruct();
        //        res.Code = "-1";
        //        res.Time = DateTime.Now;
        //        res.Info = Msg;
        //        return Json(res, JsonRequestBehavior.AllowGet);
        //    }

        //}

        #region JsApiPay


        /**
        *  
        * 从统一下单成功返回的数据中获取微信浏览器调起jsapi支付所需的参数，
        * 微信浏览器调起JSAPI时的输入参数格式如下：
        * {
        *   "appId" : "wx2421b1c4370ec43b",     //公众号名称，由商户传入     
        *   "timeStamp":" 1395712654",         //时间戳，自1970年以来的秒数     
        *   "nonceStr" : "e61463f8efa94090b1f366cccfbbb444", //随机串     
        *   "package" : "prepay_id=u802345jgfjsdfgsdg888",     
        *   "signType" : "MD5",         //微信签名方式:    
        *   "paySign" : "70EA570631E4BB79628FBCA90534C63FF7FADD89" //微信签名 
        * }
        * @return string 微信浏览器调起JSAPI时的输入参数，json格式可以直接做参数用
        * 更详细的说明请参考网页端调起支付API：http://pay.weixin.qq.com/wiki/doc/api/jsapi.php?chapter=7_7
        * 
        */
        public ActionResult GetJsApiParameters()
        {
            Log.Debug(this.GetType().ToString(), "JsApiPay::GetJsApiParam is processing...");


            Utils.ResultStruct res = new Utils.ResultStruct();
            res.Code = "-1";
            res.Time = DateTime.Now;


            string strTotal_fee = GetRequestString("total_fee");
            decimal decTotal_fee = 0;
            if (!decimal.TryParse(strTotal_fee, out decTotal_fee))
            {
                res.Info = $"非法的订单金额({strTotal_fee})，请确认或刷新重试！";
                return Json(res, JsonRequestBehavior.AllowGet);
            }
            int iTotal_fee = (int)(decimal.Parse(strTotal_fee) * 100);

            IBLL.IWxWebGrantService wwgs = new BLL.WxWebGrantService();
            string code = GetRequestString("code");
            if (wxWebGrant == null || wxWebGrant.code != code)
                wxWebGrant = wwgs.LoadEntities(g => g.code == code).FirstOrDefault();

            if (wxWebGrant == null)
            {
                res.Info = $"获取个人信息失败，请重新通过微信公众号访问！(code:{code})";
                return Json(res, JsonRequestBehavior.AllowGet);
            }

            if (wxWebGrant.acquireTime <= (DateTime.Now.AddSeconds(-(double)(wxWebGrant.expires_in - 300))))
                wxWebGrant = this.RefreshWebAccessToken(wxWebGrant.refresh_token);


            JsApiPay jsApiPay = new JsApiPay(Request);


            jsApiPay.openid = wxWebGrant.openid;
            jsApiPay.total_fee = iTotal_fee;

            WxPayData unifiedOrderResult = jsApiPay.GetUnifiedOrderResult();

            WxPayData jsApiParam = new WxPayData();
            jsApiParam.SetValue("appId", Utils.WechatHelper.appId);// unifiedOrderResult.GetValue("appid"));
            jsApiParam.SetValue("timeStamp", WxPayApi.WxPayApi.GenerateTimeStamp());
            jsApiParam.SetValue("nonceStr", WxPayApi.WxPayApi.GenerateNonceStr());
            jsApiParam.SetValue("package", "prepay_id=" + unifiedOrderResult.GetValue("prepay_id"));
            jsApiParam.SetValue("signType", "MD5");
            jsApiParam.SetValue("paySign", jsApiParam.MakeSign());

            string parameters = jsApiParam.ToJson();

            Log.Debug(this.GetType().ToString(), "Get jsApiParam : " + parameters);

            res.Code = "0";
            res.Time = DateTime.Now;
            res.Info = Msg;
            res.Data = parameters;
            return Json(res, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region GetWxJsSdk
        public ActionResult GetWxJsSdkParameters()
        {
            //string jsapi_ticket = "jsapi_ticket";

            Utils.ResultStruct res = new Utils.ResultStruct();
            // 注意 URL 一定要动态获取，不能 hardcode
            //string url = Request.Url.ToString();
            string url = Request.QueryString["url"];
            //Dictionary<string, string> ret = sign(jsapi_ticket, url);
            //for (Dictionary.Entry entry : ret.entrySet())
            //{
            //    System.out.println(entry.getKey() + ", " + entry.getValue());
            //}
            string Timestamp = WxPayApi.WxPayApi.GenerateTimeStamp();
            var noncestr = WxPayApi.WxPayApi.GenerateNonceStr();
            //if (accessToken == null || accessToken.IsGetNewToken)
            //    try
            //    {
            //        accessToken = Utils.WechatHelper.getAccessToken(Utils.WechatHelper.appId, WechatHelper.appSecret);
            //    }
            //    catch (Exception e)
            //    {
            //        Msg = e.Message;
            //        res.Code = "-1";
            //        res.Time = DateTime.Now;
            //        res.Info = Msg;
            //        return Json(res, JsonRequestBehavior.AllowGet);
            //    }
            //var jsapi_ticket = Utils.WechatHelper.GetJsApiTicket(accessToken.Token);
            var jsapi_ticket = Utils.WechatHelper.GetJsApiTicket(accessToken);

            var jmdata = "jsapi_ticket={0}&noncestr={1}&timestamp={2}&url={3}";

            jmdata = string.Format(jmdata, jsapi_ticket, noncestr, Timestamp, url);

            //string signature = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(jmdata, "SHA1");

            //string signature = BitConverter.ToString(System.Security.Cryptography.SHA1.Create().ComputeHash(System.Text.Encoding.UTF8.GetBytes(jmdata)));

            StringBuilder sb = new StringBuilder();
            foreach (byte ibyte in System.Security.Cryptography.SHA1.Create().ComputeHash(System.Text.Encoding.UTF8.GetBytes(jmdata)))
            {
                sb.AppendFormat("{0:x2}", ibyte);
            }
            string signature = sb.ToString();
            Dictionary<string, object> dic = new Dictionary<string, object>();
            dic.Add("timestamp", Timestamp);
            dic.Add("nonceStr", noncestr);
            dic.Add("signature", signature);
            dic.Add("jsApiList", new string[] { "chooseWXPay" });
            //dic.Add("jsApiList", new string[] { "scanQRCode" }); 

            res.Code = "0";
            res.Time = DateTime.Now;
            res.Info = Msg;
            res.Data = dic;
            return Json(res, JsonRequestBehavior.AllowGet);
        }

        //JAVA demo
        //public static Map<string, string> sign(string jsapi_ticket, string url)
        //{
        //    Map<string, string> ret = new Map<string, string>().;
        //    string nonce_str = WxPayApi.WxPayApi.GenerateNonceStr();
        //    string timestamp = WxPayApi.WxPayApi.GenerateTimeStamp();
        //    string string1;
        //    string signature = "";

        //    //注意这里参数名必须全部小写，且必须有序
        //    string1 = "jsapi_ticket=" + jsapi_ticket +
        //              "&noncestr=" + nonce_str +
        //              "&timestamp=" + timestamp +
        //              "&url=" + url;

        //    try
        //    {
        //        MessageDigest crypt = MessageDigest.getInstance("SHA-1");
        //        crypt.reset();
        //        crypt.update(string1.getBytes("UTF-8"));
        //        signature = byteToHex(crypt.digest());
        //    }
        //    catch (NoSuchAlgorithmException e)
        //    {
        //        e.printStackTrace();
        //    }
        //    catch (UnsupportedEncodingException e)
        //    {
        //        e.printStackTrace();
        //    }

        //    ret.put("url", url);
        //    ret.put("jsapi_ticket", jsapi_ticket);
        //    ret.put("nonceStr", nonce_str);
        //    ret.put("timestamp", timestamp);
        //    ret.put("signature", signature);

        //    return ret;
        //}

        #endregion

        #region 外部请求
        #region wxWebGrant 授权相关
        public ActionResult refreshToken()
        {
            Utils.ResultStruct res = new Utils.ResultStruct();
            // 注意 URL 一定要动态获取，不能 hardcode
            string openid = GetRequestString("openid");
            string code = GetRequestString("code");
            //if (accessToken == null || accessToken.IsGetNewToken)
            //    try
            //    {
            //        accessToken = Utils.WechatHelper.getAccessToken(Utils.WechatHelper.appId, WechatHelper.appSecret);
            //    }
            //    catch (Exception e)
            //    {
            //        Msg = e.Message;
            //        res.Code = "-2";
            //        res.Time = DateTime.Now;
            //        res.Info = Msg;
            //        return Json(res, JsonRequestBehavior.AllowGet);
            //    }

            IBLL.IWxWebGrantService wgs = new BLL.WxWebGrantService();
            WxWebGrant wg = wgs.LoadEntity(w => w.openid == openid && w.code == code);
            if (wg == null)
            {
                res.Code = "-1";
                res.Time = DateTime.Now;
                res.Info = "获取授权信息失败，须重新授权";
                return Json(res, JsonRequestBehavior.AllowGet);
            }

            try {
                wg = RefreshWebAccessToken(wg.refresh_token);

            } catch (Exception e)
            {
                wgs.DeleteEntity(wg);
                res.Code = Model.Enum.BusEnum.HttpRequestStatusCode.Success.ToString();
                res.Time = DateTime.Now;
                res.Info = e.Message;
                return Json(res, JsonRequestBehavior.AllowGet);
            }

            res.Code = "0";
            res.Time = DateTime.Now;
            res.Info = Msg;
            res.Data = wg;
            return Json(res, JsonRequestBehavior.AllowGet);
        }

        #endregion
        #endregion

        #region WxWebGrant 内部方法
        private WxWebGrant GetOpenidAndAccessToken()
        {
            if (!string.IsNullOrEmpty(Request.QueryString["code"]))
            {
                //获取code码，以获取openid和access_token
                string code = Request.QueryString["code"];
                //Log.Debug(this.GetType().ToString(), "Get code : " + code);
                return GetOpenidAndAccessTokenFromCode(code);
            }
            else
            {
                //构造网页授权获取code的URL
                string host = Request.Url.Host;
                string path = Request.Path;
                string redirect_uri = HttpUtility.UrlEncode("http://" + host + path);
                WxPayData data = new WxPayData();
                data.SetValue("appid", WxPayConfig.GetConfig().GetAppID());
                data.SetValue("redirect_uri", redirect_uri);
                data.SetValue("response_type", "code");
                data.SetValue("scope", "snsapi_base");
                data.SetValue("state", "STATE" + "#wechat_redirect");
                string url = "https://open.weixin.qq.com/connect/oauth2/authorize?" + data.ToUrl();
                Log.Debug(this.GetType().ToString(), "Will Redirect to URL : " + url);
                try
                {
                    //触发微信返回code码         
                    Request.RequestContext.HttpContext.Response.Redirect(url);//Redirect函数会抛出ThreadAbortException异常，不用处理这个异常
                    return null;
                }
                catch (System.Threading.ThreadAbortException ex)
                {
                    return null;
                }
            }
        }


        /**
	    * 
	    * 通过code换取网页授权access_token和openid的返回数据，正确时返回的JSON数据包如下：
	    * {
	    *  "access_token":"ACCESS_TOKEN",
	    *  "expires_in":7200,
	    *  "refresh_token":"REFRESH_TOKEN",
	    *  "openid":"OPENID",
	    *  "scope":"SCOPE",
	    *  "unionid": "o6_bmasdasdsad6_2sgVt7hMZOPfL"
	    * }
	    * 其中access_token可用于获取共享收货地址
	    * openid是微信支付jsapi支付接口统一下单时必须的参数
        * 更详细的说明请参考网页授权获取用户基本信息：http://mp.weixin.qq.com/wiki/17/c0f37d5704f0b64713d5d2c37b468d75.html
        * @失败时抛异常WxPayException
	    */
        public WxWebGrant GetOpenidAndAccessTokenFromCode(string code)
        {
            WxWebGrant wxWebGrant = null;
            try
            {
                //构造获取openid及access_token的url
                WxPayData data = new WxPayData();
                data.SetValue("appid", WxPayConfig.GetConfig().GetAppID());
                data.SetValue("secret", WxPayConfig.GetConfig().GetAppSecret());
                data.SetValue("code", code);
                data.SetValue("grant_type", "authorization_code");
                string url = "https://api.weixin.qq.com/sns/oauth2/access_token?" + data.ToUrl();

                //请求url以获取数据
                string result = HttpService.Get(url);
                //string result = "{\"access_token\":\"41_dYad3KTmXUsxA5f9v_fIndHJHBcymroUsU_8Sd9NbyUriC7CGkLrf9uln2nLLiPehOvT9hOKGPSG5l8evSfz6A\",\"expires_in\":7200,\"refresh_token\":\"41_lSIuo97VAULsum-zlwACZ2x3PjtjEF_PM2oj4z4sjnzEaRx0bQ7jvHroZ60afWpjrd-WL0rNKBZzsjtBKE6dKg\",\"openid\":\"oHQPu0sVahm36H1HsaMlJ-fUb4YE\",\"scope\":\"snsapi_userinfo\"}";
                Log.Debug(this.GetType().ToString(), "GetOpenidAndAccessTokenFromCode response : " + result);

                //保存access_token，用于收货地址获取
                JsonData jd = JsonMapper.ToObject(result);

                if (((System.Collections.IDictionary)jd).Contains("errcode"))
                    throw new Exception($"请求微信用户信息错误,errcode:{jd["errcode"].ToString()}:errmsg:{jd["errmsg"].ToString()}");

                //access_token = (string)jd["access_token"];

                ////获取用户openid
                //openid = (string)jd["openid"];
                BLL.WxWebGrantService wwgs = new BLL.WxWebGrantService();
                wxWebGrant = wwgs.AddEntity(new WxWebGrant()
                {
                    access_token = jd["access_token"].ToString(),
                    code = code,
                    acquireTime = DateTime.Now,
                    expires_in = int.Parse(jd["expires_in"].ToString()),
                    openid = jd["openid"].ToString(),
                    refresh_token = jd["refresh_token"].ToString(),
                    scope = jd["scope"].ToString()
                });

                Log.Debug(this.GetType().ToString(), "Get openid : " + wxWebGrant.openid);
                Log.Debug(this.GetType().ToString(), "Get access_token : " + wxWebGrant.access_token);

                return wxWebGrant;
            }
            catch (Exception ex)
            {
                Log.Error(this.GetType().ToString(), ex.ToString());
                throw new WxPayException(ex.ToString());
            }
        }
        /// <summary>
        /// 刷新网页授权,成功返回新授权对象，失败抛出异常
        /// </summary>
        /// <param name="refreshToken"></param>
        /// <returns></returns>
        /// <exception cref="WxPayException">刷新授权失败抛出异常</exception>
        public WxWebGrant RefreshWebAccessToken(string refreshToken)
        {
            try
            {
                //构造获取openid及access_token的url
                WxPayData data = new WxPayData();
                data.SetValue("appid", WxPayConfig.GetConfig().GetAppID());
                //data.SetValue("secret", WxPayConfig.GetConfig().GetAppSecret());
                data.SetValue("grant_type", "refresh_token");
                data.SetValue("refresh_token", refreshToken);
                //https://api.weixin.qq.com/sns/oauth2/refresh_token?appid=APPID&grant_type=refresh_token&refresh_token=REFRESH_TOKEN
                string url = WechatHelper.WxApiDomain + "sns/oauth2/refresh_token?" + data.ToUrl();
                //请求url以获取数据
                string result = HttpService.Get(url);
                //string result = "{\"access_token\":\"41_dYad3KTmXUsxA5f9v_fIndHJHBcymroUsU_8Sd9NbyUriC7CGkLrf9uln2nLLiPehOvT9hOKGPSG5l8evSfz6A\",\"expires_in\":7200,\"refresh_token\":\"41_lSIuo97VAULsum-zlwACZ2x3PjtjEF_PM2oj4z4sjnzEaRx0bQ7jvHroZ60afWpjrd-WL0rNKBZzsjtBKE6dKg\",\"openid\":\"oHQPu0sVahm36H1HsaMlJ-fUb4YE\",\"scope\":\"snsapi_userinfo\"}";
                Log.Debug(this.GetType().ToString(), "RefreshAccessToken response : " + result);

                //保存access_token，用于收货地址获取
                JsonData jd = JsonMapper.ToObject(result);

                if (((System.Collections.IDictionary)jd).Contains("errcode"))
                    throw new Exception($"请求微信用户信息错误,errcode:{jd["errcode"].ToString()}:errmsg:{jd["errmsg"].ToString()}");

                //access_token = (string)jd["access_token"];

                ////获取用户openid
                BLL.WxWebGrantService wwgs = new BLL.WxWebGrantService();
                wxWebGrant = wwgs.LoadEntities(r => r.refresh_token == refreshToken).FirstOrDefault();

                wxWebGrant.access_token = jd["access_token"].ToString();
                wxWebGrant.acquireTime = DateTime.Now;
                wxWebGrant.expires_in = int.Parse(jd["expires_in"].ToString());
                wxWebGrant.openid = jd["openid"].ToString();
                wxWebGrant.refresh_token = jd["refresh_token"].ToString();
                wxWebGrant.scope = jd["scope"].ToString();


                Log.Debug(this.GetType().ToString(), "Get openid : " + wxWebGrant.openid);
                Log.Debug(this.GetType().ToString(), "Get access_token : " + wxWebGrant.access_token);

                if (wwgs.UpdateEntity(wxWebGrant))
                    return wxWebGrant;
                else
                {
                    //TODO:应错误处理，暂时返回新数据 
                    return wxWebGrant;
                }
            }
            catch (Exception ex)
            {
                Log.Error(this.GetType().ToString(), ex.ToString());
                throw new WxPayException(ex.ToString());
            }
        }

        private WxWebGrant getLocalWebGrantInfoFromCode(string Code)
        {
            IBLL.IWxWebGrantService web = new BLL.WxWebGrantService();
            var ent = web.LoadEntities(w => w.code == Code).FirstOrDefault();
            //if (ent.Count() != 0)
            //{
            //    return Redirect("http://test6.ql-soft.com/wxgzh/#/?src=bd&openid=" + ent.FirstOrDefault().openid);
            //    //return View(ent);
            //}
            return ent;
        }
        #endregion

        #region JSAPI Pay基础支付  迁移到WxPayV3
        //public ActionResult QueryOrder()
        //{
        //    ResultStruct rs = new ResultStruct();
        //    rs.Time = DateTime.Now;
        //    string transaction_id = GetRequestString("transaction_id");
        //    string out_trade_no = GetRequestString("out_trade_no");

        //    if (string.IsNullOrEmpty(transaction_id) && string.IsNullOrEmpty(out_trade_no))
        //    {
        //        rs.Info = "微信订单号和商户订单号至少填写一个,微信订单号优先！";
        //        rs.Code = "-1";

        //    }
        //    else
        //    {
        //        rs.Code = "0";
        //        rs.Data = WxPayApi.business.OrderQuery.Run(transaction_id, out_trade_no);
        //    }
        //    return Json(rs, JsonRequestBehavior.AllowGet);
        //}
        #endregion

    }
}