﻿using IBLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp.Controllers
{
    public class LoginController : BaseController
    {
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult LoginWXBind()
        {
            return View();
        }

        [HttpPost]
        public ActionResult LoginWXBind(FormContext c)
        {

            string str_openid = Request.Params["openid"];
            string str_jzrlb = Request.Params["jzrlb"];
            string str_name = Request.Form["name"];
            string str_gender = GetRequestString("gender", Request);
            string str_sfz = Request.Params["sfz"];
            string str_sjh = Request.Params["sjh"];
            string str_lxdz = Request.Params["lxdz"];
            string str_jhrxm = Request.Params["jhrxm"];
            string str_jhrsfz = Request.Params["jhrsfz"];
            string str_jhrsjh = Request.Params["jhrsjh"];
            string str_jhrlxdz = Request.Params["jhrlxdz"];
            IBLL.Ijc_yhService jc_yhService = new BLL.jc_yhService();
            Model.jc_yh bp = new Model.jc_yh();
            
            try
            {
                bp = jc_yhService.AddEntity(bp);
            }
            catch (Exception e)
            {
                //if (e.GetType().Name == "DbEntityValidationException")
                //{
                this.Msg = e.Message;
                //}
                Utils.ResultStruct res = new Utils.ResultStruct();
                res.Code = "-1";
                res.Time = DateTime.Now;
                res.Info = Msg;
                res.Data = new object[1] { bp };
                return Json(res, JsonRequestBehavior.AllowGet);
            }
            //            1   就诊人类别 是   本人、子女、其他
            //2   姓名 是   张三
            //3   性别 否   取值：1，男；2，女，见字典
            //4   出生日期 否   1990 - 01 - 01
            //5   身份证号 是   210101199001011011
            //6   手机号码 是   13800001234
            //7   联系地址 否   北京市海淀区十三号街同一大厦2508室
            //8   监护人姓名 否
            //9   监护人身份证号 否   见功能说明○1

            //10  监护人手机号码 否
            //11  监护人联系地址 否

            
            return Json(Utils.RequestHelper.GetResult(""));
        }

    }
}