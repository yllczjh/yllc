﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApp.WxPayApiV3.lib;
using LitJson;
using Model;

namespace WebApp.Controllers
{
    public class LoginV1Controller : BaseController
    {
        // GET: LoginV1
        public ActionResult Index()
        {
            WxPayData webGrant = (WxPayData)Session["webGrant"];
            string userid = GetRequestString("uid");
            IBLL.Ijc_yhService yhService = new BLL.jc_yhService();
            jc_yh yh = new jc_yh();
            //已授权用户进入获取用户信息
            if (webGrant != null)
            {
                if (webGrant != null && webGrant.IsSet("openid"))
                {
                    string openid = webGrant.GetValue("openid").ToString();
                    yh = yhService.LoadEntity(y => y.标识 == openid);
                    if (yh == null)
                        yh = yhService.AddEntity(new jc_yh() { 标识 = openid, 添加时间 = DateTime.Now, 禁用 = false });
                }
                else
                {
                    //userid = sgb.userId;
                }

            }
            else
            {
                //未授权进入首页用户，判断是否携带用户ID
                if (!string.IsNullOrEmpty(userid))
                {
                    int uid = int.Parse(userid);
                    yh = yhService.LoadEntity(u => u.rowid == uid);
                }
            }

            Utils.ResultStruct res = new Utils.ResultStruct();
            res.Code = "0";
            res.Data = yh;
            //Log.Info(this.GetType().ToString(), "Index sessionid:" + Session.SessionID);
            return Json(res, JsonRequestBehavior.AllowGet);
            //return Json("", JsonRequestBehavior.AllowGet);
        }
        public ActionResult wxwebgrant()
        {
            string code = GetRequestString("code");
            //Request.Url.Segments
            string id = RouteData.GetRequiredString("id").Replace(" ", "\\");
            if (code != null)
            {
                Session["code"] = code;
                Log.Info(this.GetType().ToString(), "wxwebgrant code:" + code);
                Log.Info(this.GetType().ToString(), "wxwebgrant sessionid:" + Session.SessionID);
            }
            else
            {
                Response.Redirect("http://test6.ql-soft.com/QiLianLX/?id=" + id);
                return null;
            }
            try
            {
                WxPayData webgrant = getWxWebGrantByCode(code);
                Session["webGrant"] = webgrant;
            }
            catch (Exception ex)
            {
                //TODO:登陆异常 应做有效提示处理
                //Log.Info(this.GetType().ToString(), $"wxwebgrant code:{code},{ex.Message}");
                Response.Redirect("http://test6.ql-soft.com/QiLianLX/?id=" + id);
                return null;
            }

            Response.Redirect("http://test6.ql-soft.com/QiLianLX/?id=" + id);
            return null;
        }

        private WxPayData getWxWebGrantByCode(string code)
        {
            WxPayData wxWebGrant = new WxPayData();
            try
            {
                //构造获取openid及access_token的url
                WxPayData data = new WxPayData();
                data.SetValue("appid", WxPayConfig.GetConfig().GetAppID());
                data.SetValue("secret", WxPayConfig.GetConfig().GetAppSecret());
                data.SetValue("code", code);
                data.SetValue("grant_type", "authorization_code");
                string url = "https://api.weixin.qq.com/sns/oauth2/access_token?" + data.ToUrl();

                //请求url以获取数据
                string result = HttpService.GetForWxPayV3(url);
                //string result = "{\"access_token\":\"41_dYad3KTmXUsxA5f9v_fIndHJHBcymroUsU_8Sd9NbyUriC7CGkLrf9uln2nLLiPehOvT9hOKGPSG5l8evSfz6A\",\"expires_in\":7200,\"refresh_token\":\"41_lSIuo97VAULsum-zlwACZ2x3PjtjEF_PM2oj4z4sjnzEaRx0bQ7jvHroZ60afWpjrd-WL0rNKBZzsjtBKE6dKg\",\"openid\":\"oHQPu0sVahm36H1HsaMlJ-fUb4YE\",\"scope\":\"snsapi_userinfo\"}";
                Log.Debug(this.GetType().ToString(), "GetOpenidAndAccessTokenFromCode response : " + result);

                //保存access_token，用于收货地址获取
                JsonData jd = JsonMapper.ToObject(result);

                if (((System.Collections.IDictionary)jd).Contains("errcode"))
                    throw new Exception($"请求微信用户信息错误,errcode:{jd["errcode"].ToString()}:errmsg:{jd["errmsg"].ToString()}");
                
                wxWebGrant.SetValue("access_token", jd["access_token"].ToString());
                wxWebGrant.SetValue("acquireTime", DateTime.Now);
                wxWebGrant.SetValue("expires_in", int.Parse(jd["expires_in"].ToString()));
                wxWebGrant.SetValue("openid", jd["openid"].ToString());
                wxWebGrant.SetValue("refresh_token", jd["refresh_token"].ToString());
                wxWebGrant.SetValue("scope", jd["scope"].ToString());
              
                Log.Debug(this.GetType().ToString(), "Get openid : " + wxWebGrant.GetValue("openid").ToString());
                Log.Debug(this.GetType().ToString(), "Get access_token : " + wxWebGrant.GetValue("access_token"));

                return wxWebGrant;
            }
            catch (Exception ex)
            {
                Log.Error(this.GetType().ToString(), ex.ToString());
                throw new WxPayException(ex.ToString());
            }
        }

        public ActionResult login()
        {
            string appid = GetRequestString("appid");
                //"wx4d2cb14f8cf85cab";
            string base_url = "http://test6.ql-soft.com/";
            string url= $"https://open.weixin.qq.com/connect/oauth2/authorize?appid=" +
                $@"{appid}&redirect_uri={base_url}loginv1/wxwebgrant/hischoosePatient&response_type=code&scope=snsapi_base&state=1#wechat_redirect";
            //snsapi_userinfo       snsapi_base
            return Redirect(url);
        }
    }
}