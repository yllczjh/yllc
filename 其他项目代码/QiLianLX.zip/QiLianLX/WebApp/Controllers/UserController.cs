﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp.Controllers
{
    public class UserController : BaseController
    {
        // GET: User
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult BindInfo()
        {
            Utils.ResultStruct res = new Utils.ResultStruct();
            string xm = GetRequestString("xm");
            string sjh = GetRequestString("sjh");
            string uid = GetRequestString("uid");
            IBLL.Ijc_yhService yhService = new BLL.jc_yhService();
            Model.jc_yh yh = new Model.jc_yh();
            if (uid != null)
            {
                int userid = int.Parse(uid);
                yh = yhService.LoadEntity(u => u.rowid == userid);
                if (yh != null)
                {
                    yh.姓名 = xm;
                    yh.手机号 = sjh;

                    yhService.UpdateEntity(yh);
                }
            }

            res.Code = "0";
            res.Data = yh;
            return Json(res, JsonRequestBehavior.AllowGet);
        }
    }
}