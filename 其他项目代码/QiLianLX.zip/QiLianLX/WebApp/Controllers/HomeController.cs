﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp.Controllers
{
    public class HomeController : BaseController
    {
        // GET: Home
        public new ActionResult Index()
        {
            IBLL.IHisYuYueGuaHaoService service = new BLL.HisYuYueGuaHaoService();
            var list = service.LoadEntities(t => t.status == "申请取消");
            Session[Session.SessionID] = "session好使不";
            Response.Cookies["session"].Value = Session.SessionID;

            //foreach (Model.HisYuYueGuaHao item in list)
            //{
            //}
            ViewData["tfsq"] = list;

            IBLL.IBusTradeService bts = new BLL.BusTradeService();
            ViewData["tksq"] = bts.LoadEntities(t => t.status == "申请退款");
            return View();
        }

    }
}