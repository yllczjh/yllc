﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApp.WxPayApiV3.lib;

namespace WebApp.Controllers
{
    public class HisController : BaseController
    {
        // GET: His
        public new ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// 根据科室类型获取科室列表
        /// </summary>
        /// <returns></returns>
        public ActionResult GetKeShiLieBiao()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string StrDepartmentType = GetRequestString("depttype", Request);

            string strData = SupportTools.HisDataHelper.ExecHisOption("noid", "1001", "", StrDepartmentType);
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData.Replace("科室名称", "ksmc").Replace("科室编码", "ksbm"));
            var aa = Json(rs, JsonRequestBehavior.AllowGet);
            //new Newtonsoft.Json.JsonSerializer().Converters(aa);
            return Json(rs, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 根据科室编码获取医生列表
        /// </summary>
        /// <returns></returns>
        public ActionResult GetYiShengLieBiao()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string StrDeptCode = GetRequestString("deptCode", Request);

            string strData = SupportTools.HisDataHelper.ExecHisOption("noid", "1002", "", StrDeptCode);
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData.Replace("人员姓名", "ryxm").Replace("人员编码", "rybm"));
            var aa = Json(rs, JsonRequestBehavior.AllowGet);
            //new Newtonsoft.Json.JsonSerializer().Converters(aa);
            return Json(rs, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 根据科室编码,医生编码获取排班信息
        /// </summary>
        /// <returns></returns>
        public ActionResult GetPaiBanXinXi()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string StrDeptCode = GetRequestString("deptCode", Request);
            string StrDocCode = GetRequestString("docCode", Request);
            string StrDate = GetRequestString("date", Request);

            string strData = SupportTools.HisDataHelper.ExecHisOption("noid", "1003", "", $"{StrDeptCode}|{(string.IsNullOrEmpty(StrDocCode) ? "-1" : StrDocCode)}|{StrDate}");
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData.Replace("班次标识", "bcbz"));
            var aa = Json(rs, JsonRequestBehavior.AllowGet);
            //new Newtonsoft.Json.JsonSerializer().Converters(aa);
            return Json(rs, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 根据客户端标识获取全部已绑定就诊人信息
        /// </summary>
        /// <returns></returns>
        public ActionResult GetJiuZhenRenXinXi()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string strCode = GetRequestString("code", Request);

            string strData = SupportTools.HisDataHelper.ExecHisOption(StrOpenid, "1006", "", "");
            //strData = "{\"Code\":0,\"Time\":\"2021-01-26 17:05:40\",\"Info\":\"成功!\",\"Data\":[]}";
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData);
            var aa = Json(rs, JsonRequestBehavior.AllowGet);
            //new Newtonsoft.Json.JsonSerializer().Converters(aa);
            return Json(rs, JsonRequestBehavior.AllowGet);
        }

        public ActionResult YuYueGuaHaoDengJi()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string StrBrid = GetRequestString("brid", Request);
            string StrBcbz = GetRequestString("bcbz", Request);

            string strData = SupportTools.HisDataHelper.ExecHisOption(StrOpenid, "1007", "", $"{StrBrid}|{StrBcbz}");
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData);

            if (StrOpenid == "oHQPu0sVahm36H1HsaMlJ-fUb4YE")
            {
                rs.Data = rs.Data.ToString().Replace("\"应付金额\": 8.0,", "\"应付金额\": 0.01,");
            }
            if (rs.Code == "0")
            {
                Model.HisYuYueGuaHao hisGuaHao = new Model.HisYuYueGuaHao();
                JArray dd = (JArray)Newtonsoft.Json.JsonConvert.DeserializeObject(rs.Data.ToString());

                //foreach (JObject item in dd)
                //{
                //}
                hisGuaHao.brid = dd[0]["病人ID"].ToString();
                hisGuaHao.ddh = dd[0]["订单号"].ToString();
                hisGuaHao.yfje = (decimal?)dd[0]["应付金额"];
                hisGuaHao.gqsj = (DateTime)dd[0]["过期时间"];
                hisGuaHao.bz = dd[0]["备注"].ToString();

                IBLL.IHisYuYueGuaHaoService iyy = new BLL.HisYuYueGuaHaoService();
                hisGuaHao = iyy.AddEntity(hisGuaHao);
            }
            return Json(rs, JsonRequestBehavior.AllowGet);

        }

        public ActionResult YuYueGuaHaoZhiFu()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string StrBrid = GetRequestString("brid", Request);
            string StrDdh = GetRequestString("ddh", Request);
            string StrPtddh = GetRequestString("ptddh", Request);
            string StrPtddsj = GetRequestString("ptddsj", Request);
            string StrPtjyh = GetRequestString("ptjyh", Request);
            string StrPtjysj = GetRequestString("ptjysj", Request);
            string StrDdyfje = GetRequestString("ddyfje", Request);
            string StrPtssje = GetRequestString("ptssje", Request);

            string strData = SupportTools.HisDataHelper.ExecHisOption(StrOpenid, "1008", "",
                $"{StrBrid}|{StrDdh}|{StrPtddh}|{StrPtddsj}|{StrPtjyh}|{StrPtjysj}|{StrDdyfje}|{StrPtssje}");
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData);

            if (rs.Code == "0")
            {
                //TODO :更新预约登记的预约单号
            }
            return Json(rs, JsonRequestBehavior.AllowGet);

        }

        public ActionResult GuaHaoLiShi()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string StrBrid = GetRequestString("brid", Request);
            string StrYydh = GetRequestString("yydh", Request);
            string StrDingDanHao = GetRequestString("ddh", Request);
            string StrYuYueZhuangTai = GetRequestString("yyzt", Request);

            string strData = SupportTools.HisDataHelper.ExecHisOption(StrOpenid, "1009", "", $"{StrBrid}|{(string.IsNullOrEmpty(StrYydh) ? "-1" : StrYydh)}|{(string.IsNullOrEmpty(StrDingDanHao) ? "-1" : StrDingDanHao)}|{(string.IsNullOrEmpty(StrYuYueZhuangTai) ? "全部" : StrYuYueZhuangTai)}");
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData);
            if (rs.Code == "0")
            {
                try
                {
                    JArray dd = (JArray)Newtonsoft.Json.JsonConvert.DeserializeObject(rs.Data.ToString());
                    IBLL.IHisYuYueGuaHaoService iyy = new BLL.HisYuYueGuaHaoService();
                    foreach (JObject item in dd)
                    {
                        string dingDanHao = item.GetValue("订单号").ToString();
                        var localDd = iyy.LoadEntities(h => h.ddh == dingDanHao).FirstOrDefault();
                        string yingFuJinE = "0";
                        if (localDd != null)
                        {
                            yingFuJinE = localDd.yfje.ToString();
                            item.Add("应付金额", yingFuJinE);//foreach (JObject item in dd)
                            if (string.IsNullOrEmpty(item.GetValue("过期时间").ToString()))
                            {
                                item.Remove("过期时间");
                                item.Add("过期时间", localDd.gqsj);
                            }
                            item.Add("平台状态", localDd.status);
                            item.Add("备注", localDd.bz);
                        }
                        //hisGuaHao.brid = dd[0]["病人ID"].ToString();
                        //hisGuaHao.ddh = dd[0]["订单号"].ToString();
                        //hisGuaHao.yfje = (decimal?)dd[0]["应付金额"];
                        //hisGuaHao.gqsj = (DateTime)dd[0]["过期时间"];
                        //hisGuaHao.bz = dd[0]["备注"].ToString();

                        //hisGuaHao = iyy.AddEntity(hisGuaHao);
                    }
                    rs.Data = dd.ToString();
                }
                catch (Exception e) { }
            }
            return Json(rs, JsonRequestBehavior.AllowGet);
        }

        public ActionResult YuYueZhuangTaiChaXun()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string StrBrid = GetRequestString("brid", Request);
            string StrYydh = GetRequestString("yydh", Request);

            string strData = SupportTools.HisDataHelper.ExecHisOption(StrOpenid, "1010", "", $"{StrBrid}|{(string.IsNullOrEmpty(StrYydh) ? "-1" : StrYydh)}");
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData);
            return Json(rs, JsonRequestBehavior.AllowGet);
        }

        public ActionResult YuYueGuaHaoQuXiao()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string StrBrid = GetRequestString("brid", Request);
            string StrYydh = GetRequestString("yydh", Request);
            string StrDdh = GetRequestString("ddh", Request);
            string StrPttkh = GetRequestString("pttkh", Request);//平台退款号
            string StrPttksj = GetRequestString("pttksj", Request);

            string strData = SupportTools.HisDataHelper.ExecHisOption(StrOpenid, "1011", "", $"{StrBrid}|{StrYydh}|{StrDdh}|{StrPttkh}|{StrPttksj}");
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData);
            return Json(rs, JsonRequestBehavior.AllowGet);
        }

        public ActionResult JiuZhenLiShiChaXun()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string StrBrid = GetRequestString("brid", Request);
            string StrMzblh = GetRequestString("mzblh", Request);//门诊病历号		显示所有，传入-1
            string StrJzzt = GetRequestString("jzzt", Request);//就诊状态 可取值：全部，待接诊，已接诊

            string strData = SupportTools.HisDataHelper.ExecHisOption(StrOpenid, "1012", "", $"{StrBrid}|{(string.IsNullOrEmpty(StrMzblh) ? "-1" : StrMzblh)}|{(string.IsNullOrEmpty(StrJzzt) ? "全部" : StrJzzt)}");
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData);
            return Json(rs, JsonRequestBehavior.AllowGet);
        }

        public ActionResult MenZhenDaiJIaoFeiShenQing()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string StrBrid = GetRequestString("brid", Request);
            string StrMzblh = GetRequestString("mzblh", Request);//门诊病历号

            string strData = SupportTools.HisDataHelper.ExecHisOption(StrOpenid, "1013", "", $"{StrBrid}|{ StrMzblh}");
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData);
            return Json(rs, JsonRequestBehavior.AllowGet);
        }

        public ActionResult MenZhenDingDanShengCheng()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string StrBrid = GetRequestString("brid", Request);
            string StrMzblh = GetRequestString("mzblh", Request);//门诊病历号
            string StrSfxh = GetRequestString("sfxh", Request);//收费序号，由缴费申请1013生成

            string strData = SupportTools.HisDataHelper.ExecHisOption(StrOpenid, "1014", "", $"{StrBrid}|{ StrMzblh}|{StrSfxh}");
            //string strData = "{\"Code\":0,\"Time\":\"2021-02-22 18:10:11\",\"Info\":\"处理成功!\",\"Data\":[{\"病人ID\":\"0000024908\",\"门诊病历号\":\"2021028663\",\"收费序号\":\"A09BF39074E74D3F833A34481C613E1B\",\"订单号\":\"000093\",\"应付金额\":60.0,\"过期时间\":\"2021-02-22T18:25:11\",\"备注\":\"请在15分钟内完成支付\"}]}";

            if (StrOpenid == "oHQPu0sVahm36H1HsaMlJ-fUb4YE")
            {
                strData = strData.Replace("\"应付金额\":60.0,", "\"应付金额\":0.01,");
            }
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData);
            List<Model.BusTrade> list = new List<Model.BusTrade>();

            if (rs.Code == "0")
            {
                JArray jArray = (JArray)JsonConvert.DeserializeObject(rs.Data.ToString());
                JObject jObj = (JObject)jArray[0];

                IBLL.IBusTradeService bts = new BLL.BusTradeService();
                Model.BusTrade busTrade = new Model.BusTrade();
                busTrade.brid = StrBrid;
                busTrade.openid = StrOpenid;
                busTrade.trade_type = "门诊缴费";
                busTrade.his_trade_no = jObj.GetValue("订单号").ToString();
                busTrade.id_no = busTrade.his_trade_no;
                busTrade.his_cost_price = (decimal)jObj.GetValue("应付金额");
                busTrade.his_discount_price = 0;
                busTrade.his_receivable = (decimal)jObj.GetValue("应付金额");
                busTrade.status = Model.Enum.BusEnum.OrderStatus.待支付.ToString();
                busTrade.his_expire_time = (DateTime)jObj.GetValue("过期时间");
                busTrade.bz = jObj.GetValue("备注").ToString();
                bts.AddEntity(busTrade);

                //jObj.Remove("过期时间");
                //jObj.Add("过期时间", busTrade.his_expire_time);
                //jArray[0] = jObj;
                //rs.Data = jArray;

                list.Add(busTrade);
            }
            //rs.Data = JsonConvert.DeserializeObject(rs.Data.ToString());
            rs.Data = list;
            return Json(rs, JsonRequestBehavior.AllowGet);
        }

        public ActionResult MenZhenDingDanZhiFu()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string StrBrid = GetRequestString("brid", Request);
            string StrDdh = GetRequestString("ddh", Request);//订单号
            string StrPtddh = GetRequestString("ptddh", Request);//平台订单号
            string StrPtddsj = GetRequestString("ptddsj", Request);//平台订单时间
            string StrPtjyh = GetRequestString("ptjyh");//平台交易号
            string StrPtjysj = GetRequestString("ptjysj");//平台交易时间
            string StrDdyfje = GetRequestString("ddyfje");//订单应付金额
            string StrPtssje = GetRequestString("ptssje");//平台实收金额


            string strData = SupportTools.HisDataHelper.ExecHisOption(StrOpenid, "1015", "", $"{StrBrid}|{ StrDdh}|{StrPtddh}|{StrPtddsj}|{StrPtjyh}|{StrPtjysj}|{StrDdyfje}|{StrPtssje}");
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData);
            return Json(rs, JsonRequestBehavior.AllowGet);
        }

        public ActionResult JianYanJianChaBaoGaoLieBiao()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string StrBrid = GetRequestString("brid", Request);
            string StrBlh = GetRequestString("blh", Request);//病历号  -1，查询所有
            string StrBgly = GetRequestString("bgly", Request);//报告来源
            string StrBglx = GetRequestString("bglx", Request);//报告类型

            string strData = SupportTools.HisDataHelper.ExecHisOption(StrOpenid, "1016", "", $"{StrBrid}|{(string.IsNullOrEmpty(StrBlh) ? "-1" : StrBlh)}|{StrBgly}|{StrBglx}");
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData);
            return Json(rs, JsonRequestBehavior.AllowGet);
        }

        public ActionResult JianYanJianChaBaoGaoJieGuo()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string StrBrid = GetRequestString("brid", Request);
            string StrBlh = GetRequestString("blh", Request);//病历号
            string StrBgdh = GetRequestString("bgdh", Request);//报告单号

            string StrBglx = GetRequestString("bglx", Request);//报告类型/检查对应1017，检验对应1018

            string strData = SupportTools.HisDataHelper.ExecHisOption(StrOpenid, StrBglx.Equals("检查") ? "1017" : "1018", "", $"{StrBrid}|{ StrBlh}|{StrBgdh}");
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData);
            return Json(rs, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ZhuYuanBingRenXinXi()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string StrBrid = GetRequestString("brid", Request);
            string StrBlh = GetRequestString("zyblh", Request);//-1，查全部
            string StrZyzt = GetRequestString("zyzt", Request);//住院状态，

            string strData = SupportTools.HisDataHelper.ExecHisOption(StrOpenid, "1019", "", $"{StrBrid}|{(string.IsNullOrEmpty(StrBlh) ? "-1" : StrBlh)}|{StrZyzt}");
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData);
            return Json(rs, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ZhuYuanYaJinYuE()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string StrBrid = GetRequestString("brid", Request);
            string StrBlh = GetRequestString("zyblh", Request);

            string strData = SupportTools.HisDataHelper.ExecHisOption(StrOpenid, "1020", "", $"{StrBrid}|{StrBlh}");
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData);
            return Json(rs, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ZhuYuanYaJinZhiFu()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string StrBrid = GetRequestString("brid", Request);
            string StrBlh = GetRequestString("zyblh", Request);
            string StrPtddh = GetRequestString("ptddh", Request);//平台订单号
            string StrPtddsj = GetRequestString("ptddsj", Request);//平台订单时间
            string StrPtjyh = GetRequestString("ptjyh");//平台交易号
            string StrPtjysj = GetRequestString("ptjysj");//平台交易时间
            string StrYjje = GetRequestString("yjje");//预缴金额

            string strData = SupportTools.HisDataHelper.ExecHisOption(StrOpenid, "1021", "", $"{StrBrid}|{StrBlh}|{StrBlh}|{StrPtddh}|{StrPtddsj}|{StrPtjyh}|{StrPtjysj}|{StrYjje}");
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData);
            return Json(rs, JsonRequestBehavior.AllowGet);
        }

        public ActionResult JiaoFeiJiLuChaXun()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string StrBrid = GetRequestString("brid", Request);
            string StrDdh = GetRequestString("ddh", Request);//查询所有，请传入-1
            string StrDdzt = GetRequestString("ddzt", Request);//订单状态

            string strData = SupportTools.HisDataHelper.ExecHisOption(StrOpenid, "1022", "", $"{StrBrid}|{(string.IsNullOrEmpty(StrDdh) ? "-1" : StrDdh)}|{(string.IsNullOrEmpty(StrDdzt) ? "全部" : StrDdzt)}");
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData);
            return Json(rs, JsonRequestBehavior.AllowGet);
        }

        public ActionResult JiaoFeiMingXiChaXun()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string StrBrid = GetRequestString("brid", Request);
            string StrDdh = GetRequestString("ddh", Request);

            string strData = SupportTools.HisDataHelper.ExecHisOption(StrOpenid, "1023", "", $"{StrBrid}|{StrDdh}");
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData);
            return Json(rs, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ZhuYuanFeiYongHuiZong()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string StrBrid = GetRequestString("brid", Request);
            string StrBlh = GetRequestString("zyblh", Request);

            string strData = SupportTools.HisDataHelper.ExecHisOption(StrOpenid, "1024", "", $"{StrBrid}|{StrBlh}");
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData);
            return Json(rs, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ZhuYuanFeiYongRiQingDan()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string StrBrid = GetRequestString("brid", Request);
            string StrBlh = GetRequestString("zyblh", Request);
            string StrFyrq = GetRequestString("fyrq", Request);

            string strData = SupportTools.HisDataHelper.ExecHisOption(StrOpenid, "1025", "", $"{StrBrid}|{StrBlh}|{StrFyrq}");
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData);
            return Json(rs, JsonRequestBehavior.AllowGet);
        }

        public ActionResult XinGuanHeSuanJianCeYuYue()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string StrBrid = GetRequestString("brid", Request);
            WxPayData param = new WxPayData();
            param.SetValue("openid", StrOpenid);
            param.SetValue("brid", StrBrid);
            //string strData = SupportTools.HisDataHelper.ExecHisOption(StrOpenid, "2001", "", $"{StrBrid}");
            //Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData);
            //return Json(rs, JsonRequestBehavior.AllowGet);
            //string strData = HIS.InterfaceHIS.MZ_HeSuanJianCeYuYue(param);
            Utils.ResultStruct rs = HIS.InterfaceHIS.MZ_HeSuanJianCeYuYue(param);
            //object obj = ((string)rs.Data).Replace("\"待缴费总额\": 60.0,", "\"待缴费总额\": 0.01,");

            if (StrOpenid == "oHQPu0sVahm36H1HsaMlJ-fUb4YE")
            {
                rs.Data = rs.Data.ToString().Replace("\"待缴费总额\": 60.0,", "\"待缴费总额\": 0.01,");
            }
            return Json(rs, JsonRequestBehavior.AllowGet);
            //return Json(HIS.InterfaceHIS.MZ_HeSuanJianCeYuYue(param), JsonRequestBehavior.AllowGet);

            //Utils.ResultStruct rs = new Utils.ResultStruct();
            //rs.Code = "0";
            //rs.Info = "处理成功!";
            //rs.Data = JsonConvert.DeserializeObject("[\r\n  {\r\n    \"病人ID\": \"0000024908\",\r\n    \"门诊病历号\": \"2021028663\",\r\n    \"收费序号\": \"A09BF39074E74D3F833A34481C613E1B\",\r\n    \"项目编码\": \"S250403007\",\r\n    \"项目名称\": \"新型冠状病毒核酸检测\",\r\n    \"规格\": null,\r\n    \"数量\": 1.0,\r\n    \"单位名称\": \"项\",\r\n    \"单价\": 60.0,\r\n    \"总金额\": 60.0,\r\n    \"待缴费总额\": 60.0,\r\n    \"生成时间\": \"2021-02-22T11:51:45\"\r\n  }\r\n]");
            //rs.Data = "[\r\n  {\r\n    \"病人ID\": \"0000024908\",\r\n    \"门诊病历号\": \"2021028663\",\r\n    \"收费序号\": \"A09BF39074E74D3F833A34481C613E1B\",\r\n    \"项目编码\": \"S250403007\",\r\n    \"项目名称\": \"新型冠状病毒核酸检测\",\r\n    \"规格\": null,\r\n    \"数量\": 1.0,\r\n    \"单位名称\": \"项\",\r\n    \"单价\": 60.0,\r\n    \"总金额\": 60.0,\r\n    \"待缴费总额\": 60.0,\r\n    \"生成时间\": \"2021-02-22T11:51:45\"\r\n  }\r\n]";

            //return Json(rs, JsonRequestBehavior.AllowGet);
        }

        public ActionResult XinGuanHeSuanJianCeBaoGao()
        {
            string StrOpenid = GetRequestString("openid", Request);
            string StrBrid = GetRequestString("brid", Request);

            string strData = SupportTools.HisDataHelper.ExecHisOption(StrOpenid, "2002", "", $"{StrBrid}");
            Utils.ResultStruct rs = Utils.RequestHelper.GetResult(strData);

            JArray array = (JArray)Newtonsoft.Json.JsonConvert.DeserializeObject(rs.Data.ToString());
            if (array.Count > 0)
            {
                JArray arrSort = new JArray(array.OrderByDescending(a => a["报告时间"]));
                foreach (JObject item in arrSort)
                {
                    item["报告时间"] = ((DateTime)item["报告时间"]).ToString("yyyy-MM-dd HH:mm:ss");
                }
                rs.Data = arrSort.ToString();
            }
            return Json(rs, JsonRequestBehavior.AllowGet);
        }

        public ActionResult QuXiaoYuYueGuaHaoShenQing()
        {
            Utils.ResultStruct rs = new Utils.ResultStruct();
            try
            {
                string ddh = GetRequestString("ddh");
                IBLL.IHisYuYueGuaHaoService service = new BLL.HisYuYueGuaHaoService();
                Model.HisYuYueGuaHao yyxq = service.LoadEntity(y => y.ddh == ddh);
                if (!string.IsNullOrEmpty(yyxq.status) && yyxq.status == "预约")
                {
                    yyxq.status = "申请取消";
                    if (service.UpdateEntity(yyxq))
                    {
                        rs.Code = "0";
                        rs.Info = "申请成功";
                    }
                    else
                    {
                        rs.Code = "-1";
                        rs.Info = "申请失败";
                    }
                }
                else
                {
                    rs.Code = "-1";
                    rs.Info = "请确认当前预约状态是否可取消";
                }

            }
            catch (Exception e)
            {
                rs.Code = "-1";
                rs.Info = e.Message;
            }
            return Json(rs, JsonRequestBehavior.AllowGet);
        }
        public ActionResult DeleteYuYueGuaHao()
        {
            IBLL.IHisYuYueGuaHaoService service = new BLL.HisYuYueGuaHaoService();
            IBLL.IBusRefundService busService = new BLL.BusRefundService();
            string refund_id = "";//微信退款单号
            Utils.ResultStruct rs = new Utils.ResultStruct();
            WxPayData result = new WxPayData();

            string ddh = GetRequestString("ddh");

            Model.BusRefund busRefund = busService.LoadEntity(r => r.trade_no == ddh);//暂时按单次全额退款处理
            Model.HisYuYueGuaHao trade = service.LoadEntity(t => t.ddh == ddh);

            if (busRefund == null)
            {
                busRefund = new Model.BusRefund();
                busRefund.trade_no = ddh;
                busRefund.refund_no = WxPayApiV3.lib.WxPayApiV3.GenerateOutTradeNo();
                busRefund.create_time = DateTime.Now;
                busRefund.status = "待退款";
                busRefund = busService.AddEntity(busRefund);
            }

            refund_id = busRefund.refund_no;

            #region 微信支付端退款操作
            if (busRefund.status == "待退款")
            {
                result = WxPayApiV3.business.Refund.Run("", trade.ddh, ((int)(trade.yfje * 100)).ToString(), ((int)(trade.yfje * 100)).ToString(), busRefund.refund_no);

                if (!result.IsSet("refund_id") || result.GetValue("refund_id").ToString() == "")//!result.IsSet("appid") ||
                {
                    Log.Error(this.GetType().ToString(), "UnifiedOrder response error!");
                    //throw new WxPayException("UnifiedOrder response error!" + result.ToJsonByNewton());
                    rs.Code = "-1";
                    rs.Info = "微信支付退费失败" + result.ToJsonByNewton();
                    return Json(rs, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    //refund_id = result.GetValue("refund_id").ToString();
                    busRefund.status = "已退款";
                    busService.UpdateEntity(busRefund);
                }
            }
            #endregion

            #region HIS端取消操作
            //string StrOpenid = GetRequestString("openid", Request);
            //string StrBrid = GetRequestString("brid", Request);
            //string StrYydh = GetRequestString("yydh", Request);
            //string StrDdh = GetRequestString("ddh", Request);
            //string StrPttkh = GetRequestString("pttkh", Request);//平台退款号
            //string StrPttksj = GetRequestString("pttksj", Request);
            WxPayData hisInobj = new WxPayData();
            hisInobj.SetValue("openid", trade.openid);
            hisInobj.SetValue("brid", trade.brid);
            hisInobj.SetValue("yydh", trade.yydh);
            hisInobj.SetValue("ddh", trade.ddh);
            hisInobj.SetValue("pttkh", refund_id);
            hisInobj.SetValue("pttksj", DateTime.Now);

            rs = HIS.InterfaceHIS.MZ_QuXiaoYuYueGuaHaoShenQing(hisInobj);
            if (rs.Code != "0")
                return Json(rs, JsonRequestBehavior.AllowGet);

            #endregion

            #region 平台数据处理
            busRefund.status = "交易撤销";
            busService.UpdateEntity(busRefund);
            trade.status = "已取消";
            service.UpdateEntity(trade);
            #endregion


            //try
            //{
            //    //IBLL.IHisYuYueGuaHaoService service = new BLL.HisYuYueGuaHaoService();
            //    Model.HisYuYueGuaHao yyxq = service.LoadEntity(y => y.ddh == ddh);
            //    if (!string.IsNullOrEmpty(yyxq.status) && yyxq.status == "预约")
            //    {
            //        yyxq.status = "申请取消";
            //        if (service.UpdateEntity(yyxq))
            //        {
            //            rs.Code = "0";
            //            rs.Info = "申请成功";
            //        }
            //        else
            //        {
            //            rs.Code = "-1";
            //            rs.Info = "申请失败";
            //        }
            //    }
            //    else
            //    {
            //        rs.Code = "-1";
            //        rs.Info = "请确认当前预约状态是否可取消";
            //    }

            //}
            //catch (Exception e)
            //{
            //    rs.Code = "-1";
            //    rs.Info = e.Message;
            //}

            rs.Code = "0";
            rs.Info = "退费成功";
            rs.Data = result;
            return Json(rs, JsonRequestBehavior.AllowGet);
            //}
        }
    }
}