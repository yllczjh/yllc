﻿using LitJson;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Utils;
using WebApp.WxPayApiV3.business;
using WebApp.WxPayApiV3.lib;

namespace WebApp.Controllers
{
    public class WxPayV3Controller : BaseController
    {
        public static WxWebGrant wxWebGrant;
        // GET: WxPayV3
        public ActionResult Index()
        {
            return View();
        }

        #region wxWebGrent
        public WxWebGrant RefreshAccessToken(string refreshToken)
        {
            try
            {
                //构造获取openid及access_token的url
                WxPayData data = new WxPayData();
                data.SetValue("appid", WxPayConfig.GetConfig().GetAppID());
                //data.SetValue("secret", WxPayConfig.GetConfig().GetAppSecret());
                data.SetValue("grant_type", "refresh_token");
                data.SetValue("refresh_token", refreshToken);
                //https://api.weixin.qq.com/sns/oauth2/refresh_token?appid=APPID&grant_type=refresh_token&refresh_token=REFRESH_TOKEN
                string url = WechatHelper.WxApiDomain + "sns/oauth2/refresh_token?" + data.ToUrl();
                //请求url以获取数据
                string result = HttpService.GetForWxPayV3(url);
                //string result = "{\"access_token\":\"41_dYad3KTmXUsxA5f9v_fIndHJHBcymroUsU_8Sd9NbyUriC7CGkLrf9uln2nLLiPehOvT9hOKGPSG5l8evSfz6A\",\"expires_in\":7200,\"refresh_token\":\"41_lSIuo97VAULsum-zlwACZ2x3PjtjEF_PM2oj4z4sjnzEaRx0bQ7jvHroZ60afWpjrd-WL0rNKBZzsjtBKE6dKg\",\"openid\":\"oHQPu0sVahm36H1HsaMlJ-fUb4YE\",\"scope\":\"snsapi_userinfo\"}";
                Log.Debug(this.GetType().ToString(), "RefreshAccessToken response : " + result);

                //保存access_token，用于收货地址获取
                JsonData jd = JsonMapper.ToObject(result);

                if (((System.Collections.IDictionary)jd).Contains("errcode"))
                    throw new Exception($"请求微信用户信息错误,errcode:{jd["errcode"].ToString()}:errmsg:{jd["errmsg"].ToString()}");

                //access_token = (string)jd["access_token"];

                ////获取用户openid
                //openid = (string)jd["openid"];
                BLL.WxWebGrantService wwgs = new BLL.WxWebGrantService();
                wxWebGrant = wwgs.LoadEntities(r => r.refresh_token == refreshToken).FirstOrDefault();

                wxWebGrant.access_token = jd["access_token"].ToString();
                wxWebGrant.acquireTime = DateTime.Now;
                wxWebGrant.expires_in = int.Parse(jd["expires_in"].ToString());
                wxWebGrant.openid = jd["openid"].ToString();
                wxWebGrant.refresh_token = jd["refresh_token"].ToString();
                wxWebGrant.scope = jd["scope"].ToString();


                Log.Debug(this.GetType().ToString(), "Get openid : " + wxWebGrant.openid);
                Log.Debug(this.GetType().ToString(), "Get access_token : " + wxWebGrant.access_token);

                if (wwgs.UpdateEntity(wxWebGrant))
                    return wxWebGrant;
                else
                {
                    //TODO:应错误处理，暂时返回新数据 
                    return wxWebGrant;
                }
            }
            catch (Exception ex)
            {
                Log.Error(this.GetType().ToString(), ex.ToString());
                throw new WxPayException(ex.ToString());
            }
        }
        #endregion

        #region JSAPI Pay基础支付
        public ActionResult QueryOrder()
        {
            ResultStruct rs = new ResultStruct();
            rs.Time = DateTime.Now;
            string transaction_id = GetRequestString("transaction_id");
            string out_trade_no = GetRequestString("out_trade_no");

            if (string.IsNullOrEmpty(transaction_id) && string.IsNullOrEmpty(out_trade_no))
            {
                rs.Info = "微信订单号和商户订单号至少填写一个,微信订单号优先！";
                rs.Code = "-1";

            }
            else
            {
                try
                {
                    IBLL.IBusTradeService bts = new BLL.BusTradeService();

                    BusTrade busTrade = bts.LoadEntity(t => t.his_trade_no == out_trade_no);
                    rs.Code = "0";

                    if (busTrade.status == Model.Enum.BusEnum.OrderStatus.待支付.ToString())
                    {
                        string result = WxPayApiV3.business.OrderQuery.Run(transaction_id, out_trade_no);
                        WxPayData res = new WxPayData();
                        res.FromJson(result);

                        if (res.IsSet("transaction_id"))
                        {
                            busTrade.pay_transaction_no = res.GetValue("transaction_id").ToString();
                            busTrade.pay_trade_no = res.GetValue("out_trade_no").ToString();
                            busTrade.status = Model.Enum.BusEnum.OrderStatus.已支付.ToString();
                            bts.UpdateEntity(busTrade);
                        }
                        rs.Data = busTrade;// WxPayApiV3.business.OrderQuery.Run(transaction_id, out_trade_no);
                    }
                    else
                    {
                        rs.Data = busTrade;
                    }
                }
                catch (Exception e)
                { }
            }
            return Json(rs, JsonRequestBehavior.AllowGet);
        }

        public ActionResult JsapiPayNotify()
        {
            //GetRequestString()
            Request.Headers.ToString();
            try
            {
                Log.Info(this.GetType().ToString(), "Request.Headers------" + Request.Headers.ToString());
                //Log.Info(this.GetType().ToString(), Request.InputStream);
                Log.Info(this.GetType().ToString(), "Response.Headers-----" + Response.Headers.ToString());
                string result = "";
                using (System.IO.Stream resStream = Response.OutputStream)
                {
                    using (System.IO.StreamReader reader = new System.IO.StreamReader(resStream, System.Text.Encoding.UTF8))
                    {
                        result = reader.ReadToEnd().ToString();
                    }
                }
                Log.Info(this.GetType().ToString(), "result-----" + result);
                throw new System.Net.WebException(result);
            }
            catch (Exception e) { }
            WxPayData res = new WxPayData();
            res.SetValue("code", "");
            res.SetValue("message", "");
            throw new System.Net.WebException("异常信息");
        }
        #endregion

        #region JsApiPay


        /**
        *  
        * 从统一下单成功返回的数据中获取微信浏览器调起jsapi支付所需的参数，
        * 微信浏览器调起JSAPI时的输入参数格式如下：
        * {
        *   "appId" : "wx2421b1c4370ec43b",     //公众号名称，由商户传入     
        *   "timeStamp":" 1395712654",         //时间戳，自1970年以来的秒数     
        *   "nonceStr" : "e61463f8efa94090b1f366cccfbbb444", //随机串     
        *   "package" : "prepay_id=u802345jgfjsdfgsdg888",     
        *   "signType" : "MD5",         //微信签名方式:    
        *   "paySign" : "70EA570631E4BB79628FBCA90534C63FF7FADD89" //微信签名 
        * }
        * @return string 微信浏览器调起JSAPI时的输入参数，json格式可以直接做参数用
        * 更详细的说明请参考网页端调起支付API：http://pay.weixin.qq.com/wiki/doc/api/jsapi.php?chapter=7_7
        * 
        */
        public ActionResult GetJsApiParameters()
        {
            Log.Debug(this.GetType().ToString(), "JsApiPay::GetJsApiParam is processing...");


            Utils.ResultStruct res = new Utils.ResultStruct();
            res.Code = "-1";
            res.Time = DateTime.Now;


            string strTotal_fee = GetRequestString("total_fee");
            decimal decTotal_fee = 0;
            if (!decimal.TryParse(strTotal_fee, out decTotal_fee))
            {
                res.Info = $"非法的订单金额({strTotal_fee})，请确认或刷新重试！";
                return Json(res, JsonRequestBehavior.AllowGet);
            }
            int iTotal_fee = (int)(decimal.Parse(strTotal_fee) * 100);

            IBLL.IWxWebGrantService wwgs = new BLL.WxWebGrantService();
            string code = GetRequestString("code");
            if (wxWebGrant == null || wxWebGrant.code != code)
                wxWebGrant = wwgs.LoadEntities(g => g.code == code).FirstOrDefault();

            if (wxWebGrant == null)
            {
                res.Info = $"获取个人信息失败，请重新通过微信公众号访问！(code:{code})";
                return Json(res, JsonRequestBehavior.AllowGet);
            }

            if (wxWebGrant.acquireTime <= (DateTime.Now.AddSeconds(-(double)(wxWebGrant.expires_in - 300))))
                wxWebGrant = this.RefreshAccessToken(wxWebGrant.refresh_token);


            JsApiPay jsApiPay = new JsApiPay(Request);


            jsApiPay.openid = wxWebGrant.openid;
            jsApiPay.total_fee = iTotal_fee;
            try
            {
                WxPayData unifiedOrderResult = jsApiPay.GetUnifiedOrderResult_V3();

                WxPayData jsApiParam = new WxPayData();
                jsApiParam.SetValue("appId", Utils.WechatHelper.appId);// unifiedOrderResult.GetValue("appid"));
                jsApiParam.SetValue("timeStamp", WxPayApi.WxPayApi.GenerateTimeStamp());
                jsApiParam.SetValue("nonceStr", WxPayApi.WxPayApi.GenerateNonceStr());
                jsApiParam.SetValue("package", "prepay_id=" + unifiedOrderResult.GetValue("prepay_id"));
                jsApiParam.SetValue("signType", "RSA");
                //jsApiParam.SetValue("paySign", jsApiParam.MakeSign());
                jsApiParam.SetValue("paySign", jsApiParam.MakeSign(WxPayData.SIGN_TYPE_SHA256_WITH_RSA));

                string parameters = jsApiParam.ToJson();

                Log.Debug(this.GetType().ToString(), "Get jsApiParam : " + parameters);

                res.Code = "0";
                res.Time = DateTime.Now;
                res.Info = Msg;
                res.Data = parameters;
            }
            catch (Exception e)
            {
                res.Code = "-1";
                res.Time = DateTime.Now;
                res.Info = e.Message;
            }
            return Json(res, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 查询单笔退款，根据商户退款单号
        /// </summary>
        /// <returns></returns>
        public ActionResult RefundQuery()
        {
            string out_refund_no = GetRequestString("out_refund_no");
            var result = WxPayApiV3.business.RefundQuery.Run(out_refund_no);
            ResultStruct rs = new ResultStruct();
            rs.Code = "0";
            rs.Data = result.ToJsonByNewton();
            return Json(rs, JsonRequestBehavior.AllowGet);
        }
        #endregion

    }
}