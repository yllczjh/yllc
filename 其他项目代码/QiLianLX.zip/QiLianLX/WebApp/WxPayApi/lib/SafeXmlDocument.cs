﻿
using System.Xml;

namespace WebApp.WxPayApi.lib
{
    public class SafeXmlDocument: XmlDocument
    {
        public SafeXmlDocument()
        {
            this.XmlResolver = null;
        }
    }
}